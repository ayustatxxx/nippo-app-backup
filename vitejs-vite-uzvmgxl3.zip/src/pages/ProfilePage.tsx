import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import MainFooterNav from '../components/MainFooterNav';
import Header from '../components/Header'; 
import { User } from '../types';

const ProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [saving, setSaving] = useState(false);
  
  // プロフィール写真関連の状態
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [tempProfileImage, setTempProfileImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // 編集用の状態
  const [formData, setFormData] = useState({
    username: '',
    fullName: '',
    company: '',
    position: '',
    phone: '',
    email: '',
    notifications: true,
    reportFrequency: 'daily' as 'daily' | 'weekly' | 'monthly'
  });

  // 📝 修正：ダミーユーザー作成関数を先に定義
  const createDummyUser = (userId: string, username: string): User => {
    return {
      id: userId,
      email: "admin@example.com",
      username: username,
      role: "admin",
      groups: [],
      profileData: {
        fullName: "管理者ユーザー",
        company: "株式会社 Night Train Stars",
        position: "システム管理者",
        phone: "03-1234-5678"
      },
      settings: {
        notifications: true,
        reportFrequency: "daily"
      },
      isActive: true,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
  };

  // 選択された画像を処理する関数
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    
    if (file) {
      // 画像ファイルをBase64に変換
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setTempProfileImage(result);
      };
      reader.readAsDataURL(file);
    }
  };

  // プロフィール写真を選択する関数
  const handleImageSelect = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  


  useEffect(() => {
    const loadProfile = () => {
      console.log('📱 ProfilePage: データ読み込み開始');
      
      try {
        // ✅ ユーザーIDの確実な取得
        const userId = localStorage.getItem("daily-report-user-id") || "admin_user";
        
        // ✅ ユーザー名の確実な取得（複数ソースから）
        const storedUserData = localStorage.getItem("daily-report-user-data");
        let userName = "ユーザー"; // デフォルト値
        
        if (storedUserData) {
          try {
            const userData = JSON.parse(storedUserData);
            // 🔧 複数のソースから名前を取得
            userName = userData.profileData?.fullName || 
                      userData.username || 
                      localStorage.getItem("daily-report-username") ||
                      "ユーザー"; // フォールバック
            
            console.log('💾 ローカルデータから名前取得:', {
              fullName: userData.profileData?.fullName,
              username: userData.username,
              finalName: userName
            });
  
           // ✅ 既存のユーザーデータを使用
const finalUserData = {
  ...userData,
  username: userName // 確実に取得した名前を設定
};
setUser(finalUserData);

// ✅ FormDataの設定
setFormData({
  username: userName,
  fullName: userData.profileData?.fullName || userName,
  email: userData.email || "",
  company: userData.profileData?.company || "",
  position: userData.profileData?.position || "",
  phone: userData.profileData?.phone || "",
  notifications: userData.settings?.notifications ?? true,
  reportFrequency: userData.settings?.reportFrequency || "daily"
});

console.log('✅ 保存されたプロフィールデータを復元しました:', userName);
console.log('🔧 最終ユーザーデータ:', finalUserData);
            

          } catch (error) {
            console.error('❌ ユーザーデータ解析エラー:', error);
            // エラー時はダミーデータを作成
            const dummyUser = {
              id: userId,
              username: userName,
              email: "user@example.com",
              role: "user",
              groups: [],
              profileData: {
                fullName: userName,
                company: "",
                position: "",
                phone: ""
              },
              settings: {
                notifications: true,
                reportFrequency: "daily"
              },
              isActive: true,
              createdAt: Date.now(),
              updatedAt: Date.now()
            };
            setUser(dummyUser);
            setFormData({
              username: userName,
              fullName: userName,
              email: "user@example.com",
              company: "",
              position: "",
              phone: "",
              notifications: true,
              reportFrequency: "daily"
            });
          }
        } else {
          // 初回アクセス時のダミーデータ作成
          const username = localStorage.getItem("daily-report-username") || "ユーザー";
          const dummyUser = {
            id: userId,
            username: username,
            email: "user@example.com",
            role: "user",
            groups: [],
            profileData: {
              fullName: username,
              company: "",
              position: "",
              phone: ""
            },
            settings: {
              notifications: true,
              reportFrequency: "daily"
            },
            isActive: true,
            createdAt: Date.now(),
            updatedAt: Date.now()
          };
          setUser(dummyUser);
          setFormData({
            username: username,
            fullName: username,
            email: "user@example.com",
            company: "",
            position: "",
            phone: "",
            notifications: true,
            reportFrequency: "daily"
          });
          console.log('🆕 初回アクセス - ダミーデータを作成しました');
        }
  
        // プロフィール画像の復元
        const storedProfileImage = localStorage.getItem("daily-report-profile-image");
        if (storedProfileImage) {
          setProfileImage(storedProfileImage);
          console.log("🖼️ プロフィール画像を復元しました");
        }
        
      } catch (error) {
        console.error('❌ プロフィールロードエラー:', error);
      }
  
      console.log('✅ ProfilePage: データ読み込み完了');
    };
  
    loadProfile();
  }, []);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    // チェックボックスの場合は checked 値を使用
    const inputValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    
    setFormData({
      ...formData,
      [name]: inputValue
    });
  };
  
  // 📝 修正：saveProfile関数
  // ProfilePage.tsx のsaveProfile関数を以下に置き換えてください：

const saveProfile = async () => {
  if (!user) return;
  
  try {
    setSaving(true);
    
    // 🔧 修正：フォームデータから確実にユーザー名を取得
    const finalUsername = formData.username || formData.fullName || user.username || "デフォルトユーザー";
    const finalFullName = formData.fullName || formData.username || user.profileData?.fullName || "デフォルトユーザー";
    
    console.log("💾 保存データ確認:", {
      formUsername: formData.username,
      formFullName: formData.fullName,
      finalUsername: finalUsername,
      finalFullName: finalFullName
    });
    
    // 更新されたユーザー情報
    const updatedUser: User = {
      ...user,
      username: finalUsername,
      email: formData.email || user.email,
      profileData: {
        fullName: finalFullName,
        company: formData.company || user.profileData?.company || '',
        position: formData.position || user.profileData?.position || '',
        phone: formData.phone || user.profileData?.phone || ''
      },
      settings: {
        ...user.settings,
        notifications: formData.notifications,
        reportFrequency: formData.reportFrequency
      },
      updatedAt: Date.now()
    };
    
    console.log("📝 保存予定のユーザーデータ:", updatedUser);
    
    // プロフィール画像の更新
    if (tempProfileImage) {
      updatedUser.profileImage = tempProfileImage;
      localStorage.setItem("daily-report-profile-image", tempProfileImage);
      setProfileImage(tempProfileImage);
    }
    
    // ローカルストレージに保存
console.log("💾 保存開始 - updatedUser:", updatedUser);
console.log("💾 保存開始 - username:", updatedUser.username);
console.log("💾 保存開始 - fullName:", updatedUser.profileData.fullName);

localStorage.setItem("daily-report-user-data", JSON.stringify(updatedUser));
localStorage.setItem("daily-report-username", updatedUser.profileData.fullName || "ユーザー");
localStorage.setItem("daily-report-user-id", updatedUser.id);
localStorage.setItem("daily-report-profile-name", updatedUser.profileData.fullName);

console.log("💾 保存完了 - 確認:");
console.log("💾 username:", localStorage.getItem("daily-report-username"));
console.log("💾 profile-name:", localStorage.getItem("daily-report-profile-name"));
    
    console.log("💾 ローカルストレージ保存完了:", {
      username: updatedUser.username,
      fullName: updatedUser.profileData.fullName
    });
    

  

    // Firestoreのグループメンバー情報も同期更新（エラーハンドリング強化）
    try {
      console.log("🔄 Firestoreのメンバー情報を同期中...");
      
      // 動的インポートでエラー回避
      const dbModule = await import('../utils/dbUtil');
      if (dbModule.getGroupsByUser && dbModule.updateGroup) {
        const userGroups = await dbModule.getGroupsByUser(updatedUser.id);
        
        // 各グループのメンバー情報を更新
        for (const group of userGroups) {
          if (group.members) {
            const updatedMembers = group.members.map((member: User) => {
              if (member.id === updatedUser.id) {
                return {
                  ...member,
                  username: updatedUser.username,
                  email: updatedUser.email,
                  profileData: updatedUser.profileData,
                  profileImage: updatedUser.profileImage,
                  updatedAt: updatedUser.updatedAt
                };
              }
              return member;
            });
            
            const updatedGroup = {
              ...group,
              members: updatedMembers,
              updatedAt: Date.now()
            };
            
            await dbModule.updateGroup(group.id, updatedGroup);
            console.log("✅ グループメンバー情報を更新:", group.name);
          }
        }
        console.log("🎉 Firestoreメンバー情報同期完了!");
      } else {
        console.log("⚠️ Firestore同期関数が利用できません（ローカル保存は成功）");
      }
    } catch (syncError) {
      console.error("⚠️ Firestore同期エラー（ローカル保存は成功）:", syncError);
    }
    
    // ユーザー情報を更新
    setUser(updatedUser);
    setEditMode(false);
    
    // 一時画像をクリア
    setTempProfileImage(null);
    
    console.log("✅ プロフィール情報を保存しました:", updatedUser.username);
    
    // 成功アニメーションを表示
    const successElement = document.createElement('div');
    successElement.textContent = '✓ 保存しました';
    successElement.style.position = 'fixed';
    successElement.style.top = '50%';
    successElement.style.left = '50%';
    successElement.style.transform = 'translate(-50%, -50%)';
    successElement.style.backgroundColor = '#4CAF50';
    successElement.style.color = 'white';
    successElement.style.padding = '16px';
    successElement.style.borderRadius = '8px';
    successElement.style.zIndex = '1000';
    successElement.style.opacity = '0';
    successElement.style.transition = 'opacity 0.3s ease-in-out';
    
    document.body.appendChild(successElement);
    
    // フェードインアニメーション
    setTimeout(() => {
      successElement.style.opacity = '1';
    }, 10);
    
    // 2秒後に削除
    setTimeout(() => {
      successElement.style.opacity = '0';
      setTimeout(() => {
        document.body.removeChild(successElement);
      }, 300);
    }, 2000);
    
  } catch (error) {
    console.error('❌ プロフィール更新エラー:', error);
    alert('プロフィールの更新に失敗しました');
  } finally {
    setSaving(false);
  }
};
  
  const toggleEditMode = () => {
    if (editMode) {
      // 編集モードをキャンセルして元の値に戻す
      if (user) {
        setFormData({
          username: user.username,
          fullName: user?.profileData?.fullName || '',
company: user?.profileData?.company || '',
position: user?.profileData?.position || '',
phone: user?.profileData?.phone || '',
          email: user.email || '',
          notifications: user?.settings?.notifications ?? true,
reportFrequency: user?.settings?.reportFrequency || 'daily'
        });
      }
      // 一時プロフィール画像もリセット
      setTempProfileImage(null);
    }
    setEditMode(!editMode);
  };
  
  // ログアウト処理
const handleLogout = () => {
  // 💡 修正：プロフィールデータは保持し、認証情報のみクリア
  
  // 1. 現在のプロフィールデータを一時的に保存
  const currentUserData = localStorage.getItem("daily-report-user-data");
  const currentProfileImage = localStorage.getItem("daily-report-profile-image");
  
  // 2. 認証関連の情報のみクリア
  localStorage.removeItem("daily-report-user-token");
  localStorage.removeItem("daily-report-user-email");
  sessionStorage.removeItem("daily-report-user-token");
  sessionStorage.removeItem("daily-report-user-email");
  sessionStorage.removeItem("daily-report-username");
  sessionStorage.removeItem("daily-report-user-id");
  
  // 3. プロフィールデータは保持（削除しない）
  // localStorage.removeItem("daily-report-username"); → 削除
  // localStorage.removeItem("daily-report-user-id"); → 削除
  // localStorage.removeItem("daily-report-user-data"); → 削除しない
  // localStorage.removeItem("daily-report-profile-image"); → 削除しない
  
  console.log("🔓 ログアウト処理完了 - プロフィールデータは保持されます");
  
  // 4. ログインページへリダイレクト
  navigate("/login");
};

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#ffffff',
        padding: '1.5rem',
        boxSizing: 'border-box',
        paddingBottom: '80px',
      }}
    >
      <style>
        {`
          /* スピンアニメーション */
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
          
          /* 入力フィールドのフォーカススタイル */
          .profile-input:focus {
            border-color: #055A68;
            box-shadow: 0 0 0 2px rgba(5, 90, 104, 0.2);
            outline: none;
          }
          
          /* スイッチトグル */
          .toggle-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
          }
          
          .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
          }
          
          .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 24px;
          }
          
          .slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
          }
          
          input:checked + .slider {
            background-color: #055A68;
          }
          
          input:checked + .slider:before {
            transform: translateX(26px);
          }
          
          /* ボタンのホバー効果 */
          .btn {
            transition: all 0.3s ease;
          }
          
          .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          }
          
          /* カード効果 */
          .profile-card {
            transition: all 0.3s ease;
          }
          
          .profile-card:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
          }
          
          /* 画像アップロードボタン */
          .upload-overlay {
            position: absolute;
            bottom: 0;
            right: 0;
            background-color: rgba(0, 0, 0, 0.5);
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            opacity: 0;
            transition: opacity 0.3s ease;
          }
          
          .profile-image-container:hover .upload-overlay {
            opacity: 1;
          }
        `}
      </style>
      <Header 
        title="NIPPO" 
        showBackButton={false}
      />
      <div style={{ 
        maxWidth: '480px', 
        margin: '0 auto',
        paddingTop: '70px',
      }}>
        {/* ヘッダー部分 */}
        <div
          style={{
            marginTop: '0.2rem',
            marginBottom: '1rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <h2 style={{ 
            fontSize: '2rem', 
            letterSpacing: '0.01em', 
            color: '#055A68', 
            margin: 0
          }}>
            Profile
          </h2>
        </div>

        {/* プロフィール情報 */}
        {user && (
          <>
            {/* プロフィールカード */}
            <div
              className="profile-card"
              style={{
                backgroundColor: 'white',
                borderRadius: '16px',
                padding: 0,
                marginBottom: '1.5rem',
                color: '#055A68',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                overflow: 'hidden',
              }}
            >
              {/* ユーザー情報ヘッダー部分 - 背景色付き */}
              <div style={{
                backgroundColor: '#E6EDED',
                padding: '2rem',
                position: 'relative',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                borderBottom: '1px solid rgba(5, 90, 104, 0.1)'
              }}>
                {/* 非表示のファイル入力 */}
                <input 
                  type="file"
                  ref={fileInputRef}
                  style={{ display: 'none' }}
                  accept="image/*"
                  onChange={handleImageChange}
                />
                
                {/* アバター表示 - 編集モードでは変更可能に */}
                <div 
                  className="profile-image-container"
                  style={{
                    width: '100px',
                    height: '100px',
                    borderRadius: '50%',
                    backgroundColor: '#ffffff',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    overflow: 'hidden',
                    marginBottom: '1rem',
                    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
                    border: '4px solid white',
                    position: 'relative'
                  }}
                >
                  {(editMode ? tempProfileImage || profileImage : profileImage) ? (
                    <img 
                      src={editMode ? tempProfileImage || profileImage : profileImage} 
                      alt="プロフィール写真"
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover'
                      }}
                    />
                  ) : (
                    <svg 
                      width="60"
                      height="60"
                      viewBox="0 0 24 24" 
                      fill="#055A68" 
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M12 12C14.21 12 16 10.21 16 8C16 5.79 14.21 4 12 4C9.79 4 8 5.79 8 8C8 10.21 9.79 12 12 12ZM12 14C9.33 14 4 15.34 4 18V20H20V18C20 15.34 14.67 14 12 14Z" />
                    </svg>
                  )}
                  
                  {/* 編集モードの場合、画像アップロードボタンを表示 */}
                  {editMode && (
                    <div 
                      className="upload-overlay"
                      onClick={handleImageSelect}
                    >
                      <svg 
                        width="18" 
                        height="18" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="white"
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round"
                      >
                        <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                        <circle cx="8.5" cy="7" r="4" />
                        <line x1="20" y1="8" x2="20" y2="14" />
                        <line x1="23" y1="11" x2="17" y2="11" />
                      </svg>
                    </div>
                  )}
                </div>

                {/* ユーザー名 - 編集モードでは編集可能に */}


                {editMode ? (
  <input
    type="text"
    name="username"
    value={formData.username}
    onChange={handleInputChange}
    className="profile-input"
    style={{
      textAlign: 'center',
      padding: '0.5rem',
      fontSize: '1.6rem',
      fontWeight: '600',
      color: '#055A68',
      background: 'rgba(255, 255, 255, 0.5)',
      border: '1px solid #ddd',
      borderRadius: '8px',
      marginBottom: '0.5rem',
      width: '100%',
      maxWidth: '250px'
    }}
  />
) : (
  <h3 style={{ 
    margin: 0, 
    fontSize: '1.6rem', 
    color: '#055A68',
    fontWeight: '600',
    marginBottom: '0.5rem',
    textAlign: 'center'
  }}>
    {user.profileData?.fullName || user.username || formData.fullName || formData.username || "田中太郎"}
  </h3>
)}
                
                <div
                  style={{
                    backgroundColor: user.role === 'admin' ? '#055A6822' : '#ffffff33', 
                    color: '#055A68', 
                    display: 'inline-block',
                    padding: '0.3rem 0.8rem',
                    borderRadius: '20px',
                    fontSize: '0.8rem',
                    fontWeight: '500',
                    marginBottom: '0.5rem'
                  }}
                >
                  {user.role === 'admin' ? '管理者' : 'メンバー'}
                </div>
                
                {/* 最終更新日時 */}
                <div style={{ 
                  fontSize: '0.8rem', 
                  color: '#055A68', 
                  opacity: 0.7,
                  marginTop: '0.5rem'
                }}>
                  最終更新：{new Date(user.updatedAt).toLocaleDateString('ja-JP')}
                </div>
              </div>

              {/* フォーム（表示モード or 編集モード） */}
              <div style={{ padding: '1.5rem' }}>
                {editMode ? (
                  // 編集モード
                  <div>
                    {/* プロフィール編集見出し */}
                    <h4 style={{ 
                      fontSize: '1.1rem', 
                      color: '#055A68', 
                      marginTop: 0,
                      marginBottom: '1.5rem',
                      fontWeight: '600'
                    }}>
                      プロフィール情報を編集
                    </h4>

                    {/* 氏名 */}
                    <div style={{ marginBottom: '1.5rem' }}>
                      <label
                        style={{
                          display: 'block',
                          marginBottom: '0.5rem',
                          color: '#055A68',
                          fontSize: '0.9rem',
                          fontWeight: '500'
                        }}
                      >
                        氏名
                      </label>
                      <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        className="profile-input"
                        style={{
                          width: '100%',
                          padding: '0.8rem',
                          backgroundColor: '#f5f5f5',
                          border: '1px solid #ddd',
                          borderRadius: '8px',
                          color: '#055A68',
                          fontSize: '1rem',
                          boxSizing: 'border-box',
                          transition: 'all 0.3s ease'
                        }}
                        placeholder="氏名を入力"
                      />
                    </div>

                    {/* メールアドレス */}
                    <div style={{ marginBottom: '1.5rem' }}>
                      <label
                        style={{
                          display: 'block',
                          marginBottom: '0.5rem',
                          color: '#055A68',
                          fontSize: '0.9rem',
                          fontWeight: '500'
                        }}
                      >
                        メールアドレス
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="profile-input"
                        style={{
                          width: '100%',
                          padding: '0.8rem',
                          backgroundColor: '#f5f5f5',
                          border: '1px solid #ddd',
                          borderRadius: '8px',
                          color: '#055A68',
                          fontSize: '1rem',
                          boxSizing: 'border-box',
                          transition: 'all 0.3s ease'
                        }}
                        placeholder="メールアドレスを入力"
                      />
                    </div>

                    {/* 会社名 */}
                    <div style={{ marginBottom: '1.5rem' }}>
                      <label
                        style={{
                          display: 'block',
                          marginBottom: '0.5rem',
                          color: '#055A68',
                          fontSize: '0.9rem',
                          fontWeight: '500'
                        }}
                      >
                        会社名
                      </label>
                      <input
                        type="text"
                        name="company"
                        value={formData.company}
                        onChange={handleInputChange}
                        className="profile-input"
                        style={{
                          width: '100%',
                          padding: '0.8rem',
                          backgroundColor: '#f5f5f5',
                          border: '1px solid #ddd',
                          borderRadius: '8px',
                          color: '#055A68',
                          fontSize: '1rem',
                          boxSizing: 'border-box',
                          transition: 'all 0.3s ease'
                        }}
                        placeholder="会社名を入力"
                      />
                    </div>

                    {/* 役職 */}
                    <div style={{ marginBottom: '1.5rem' }}>
                      <label
                        style={{
                          display: 'block',
                          marginBottom: '0.5rem',
                          color: '#055A68',
                          fontSize: '0.9rem',
                          fontWeight: '500'
                        }}
                      >
                        役職
                      </label>
                      <input
                        type="text"
                        name="position"
                        value={formData.position}
                        onChange={handleInputChange}
                        className="profile-input"
                        style={{
                          width: '100%',
                          padding: '0.8rem',
                          backgroundColor: '#f5f5f5',
                          border: '1px solid #ddd',
                          borderRadius: '8px',
                          color: '#055A68',
                          fontSize: '1rem',
                          boxSizing: 'border-box',
                          transition: 'all 0.3s ease'
                        }}
                        placeholder="役職を入力"
                      />
                    </div>

                    {/* 電話番号 */}
                    <div style={{ marginBottom: '2rem' }}>
                      <label
                        style={{
                          display: 'block',
                          marginBottom: '0.5rem',
                          color: '#055A68',
                          fontSize: '0.9rem',
                          fontWeight: '500'
                        }}
                      >
                        電話番号
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="profile-input"
                        style={{
                          width: '100%',
                          padding: '0.8rem',
                          backgroundColor: '#f5f5f5',
                          border: '1px solid #ddd',
                          borderRadius: '8px',
                          color: '#055A68',
                          fontSize: '1rem',
                          boxSizing: 'border-box',
                          transition: 'all 0.3s ease'
                        }}
                        placeholder="電話番号を入力"
                      />
                    </div>

                    {/* 設定見出し */}
                    <h4 style={{ 
                      fontSize: '1.1rem', 
                      color: '#055A68', 
                      marginTop: '2rem',
                      marginBottom: '1.5rem',
                      fontWeight: '600'
                    }}>
                      アプリ設定
                    </h4>

                    {/* 通知設定 */}
                    <div style={{ 
                      marginBottom: '1.5rem',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      backgroundColor: '#f5f5f5',
                      padding: '1rem',
                      borderRadius: '8px'
                    }}>
                      <div>
                        <label
                          style={{
                            color: '#055A68',
                            fontSize: '1rem',
                            fontWeight: '500',
                            marginBottom: '0.2rem',
                            display: 'block'
                          }}
                        >
                          通知
                        </label>
                        <div style={{ 
                          color: '#055A68', 
                          opacity: 0.7, 
                          fontSize: '0.8rem' 
                        }}>
                          アプリからの通知を受け取る
                        </div>
                      </div>

                      <label className="toggle-switch">
                        <input
                          type="checkbox"
                          name="notifications"
                          checked={formData.notifications}
                          onChange={handleInputChange}
                        />
                        <span className="slider"></span>
                      </label>
                    </div>

                    {/* レポート頻度 */}
                    <div style={{ marginBottom: '2rem' }}>
                      <label
                        style={{
                          display: 'block',
                          marginBottom: '0.5rem',
                          color: '#055A68',
                          fontSize: '0.9rem',
                          fontWeight: '500'
                        }}
                      >
                        レポート頻度
                      </label>
                      <select
                        name="reportFrequency"
                        value={formData.reportFrequency}
                        onChange={handleInputChange}
                        className="profile-input"
                        style={{
                          width: '100%',
                          padding: '0.8rem',
                          backgroundColor: '#f5f5f5',
                          border: '1px solid #ddd',
                          borderRadius: '8px',
                          color: '#055A68',
                          fontSize: '1rem',
                          boxSizing: 'border-box',
                          appearance: 'none',
                          backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23055A68\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6 9 12 15 18 9\'%3e%3c/polyline%3e%3c/svg%3e")',
                          backgroundRepeat: 'no-repeat',
                          backgroundPosition: 'right 1rem center',
                          backgroundSize: '1em',
                          transition: 'all 0.3s ease'
                        }}
                      >
                        <option value="daily">毎日</option>
                        <option value="weekly">毎週</option>
                        <option value="monthly">毎月</option>
                      </select>
                    </div>

                    {/* ボタン並べて表示 */}
                    <div style={{ 
                      display: 'flex', 
                      gap: '1rem', 
                      marginTop: '2rem'
                    }}>
                      {/* キャンセルボタン */}
                      <button
                        onClick={toggleEditMode}
                        className="btn"
                        style={{
                          flex: '1',
                          padding: '0.8rem',
                          backgroundColor: '#f5f5f5',
                          color: '#055A68',
                          border: 'none',
                          borderRadius: '8px',
                          fontSize: '1rem',
                          cursor: 'pointer',
                          fontWeight: '500'
                        }}
                      >
                        キャンセル
                      </button>
                      
                      {/* 保存ボタン */}
                      <button
                        onClick={saveProfile}
                        disabled={saving}
                        className="btn"
                        style={{
                          flex: '1',
                          padding: '0.8rem',
                          backgroundColor: '#055A68',
                          color: 'white',
                          border: 'none',
                          borderRadius: '8px',
                          fontSize: '1rem',
                          fontWeight: '600',
                          cursor: saving ? 'default' : 'pointer',
                          opacity: saving ? 0.7 : 1,
                          display: 'flex',
                          justifyContent: 'center',
                          alignItems: 'center',
                        }}
                      >
                        {saving ? (
                          <div
                            style={{
                              width: '20px',
                              height: '20px',
                              border: '2px solid rgba(255, 255, 255, 0.3)',
                              borderTop: '2px solid white',
                              borderRadius: '50%',
                              animation: 'spin 1s linear infinite',
                            }}
                          />
                        ) : (
                          '変更を保存'
                        )}
                      </button>
                    </div>
                  </div>
                ) : (
                  // 表示モード
                  <div>
                    {/* プロフィール情報見出し */}
                    <div style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginBottom: '1.5rem',
                      paddingBottom: '0.5rem',
                      borderBottom: '1px solid rgba(5, 90, 104, 0.1)'
                    }}>
                      <h4 style={{ 
                        fontSize: '1.1rem', 
                        color: '#055A68', 
                        margin: 0,
                        fontWeight: '600'
                      }}>
                        プロフィール情報
                      </h4>

                      {/* 編集ボタン */}
                      <button
                        onClick={toggleEditMode}
                        className="btn"
                        style={{
                          background: 'none',
                          border: 'none',
                          fontSize: '0.9rem',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          color: '#055A68',
                          fontWeight: '500'
                        }}
                      >
                        <svg 
                          width="16" 
                          height="16" 
                          viewBox="0 0 24 24" 
                          fill="none" 
                          stroke="currentColor"
                          strokeWidth="2" 
                          strokeLinecap="round" 
                          strokeLinejoin="round"
                          style={{ marginRight: '0.4rem' }}
                        >
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                        </svg>
                        編集する
                      </button>
                    </div>

                    {/* プロフィール情報表示 - カード形式 */}
                    <div style={{
                      backgroundColor: '#f9f9f9',
                      padding: '1.5rem',
                      borderRadius: '12px',
                      marginBottom: '2rem'
                    }}>
                      {/* 各情報の表示 */}
                      <div style={{ marginBottom: '1.5rem' }}>
                        <div style={{ 
                          fontSize: '0.85rem', 
                          color: '#055A68', 
                          opacity: 0.8,
                          marginBottom: '0.4rem' 
                        }}>
                          氏名
                        </div>
                        <div style={{ 
                          fontSize: '1.1rem',
                          fontWeight: '500' 
                        }}>
                          {user?.profileData?.fullName || '未設定'}
                        </div>
                      </div>

                      <div style={{ marginBottom: '1.5rem' }}>
                        <div style={{ 
                          fontSize: '0.85rem', 
                          color: '#055A68', 
                          opacity: 0.8,
                          marginBottom: '0.4rem' 
                        }}>
                          メールアドレス
                        </div>
                        <div style={{ 
                          fontSize: '1.1rem',
                          fontWeight: '500' 
                        }}>
                          {user.email}
                        </div>
                      </div>

                      <div style={{ marginBottom: '1.5rem' }}>
                        <div style={{ 
                          fontSize: '0.85rem', 
                          color: '#055A68', 
                          opacity: 0.8,
                          marginBottom: '0.4rem' 
                        }}>
                          会社名
                        </div>
                        <div style={{ 
                          fontSize: '1.1rem',
                          fontWeight: '500' 
                        }}>
                          {user?.profileData?.company || '未設定'}
                        </div>
                      </div>

                      <div style={{ marginBottom: '1.5rem' }}>
                        <div style={{ 
                          fontSize: '0.85rem', 
                          color: '#055A68', 
                          opacity: 0.8,
                          marginBottom: '0.4rem' 
                        }}>
                          役職
                        </div>
                        <div style={{ 
                          fontSize: '1.1rem',
                          fontWeight: '500' 
                        }}>
                         {user?.profileData?.position || '未設定'}
                        </div>
                      </div>

                      <div style={{ marginBottom: '0' }}>
                        <div style={{ 
                          fontSize: '0.85rem', 
                          color: '#055A68', 
                          opacity: 0.8,
                          marginBottom: '0.4rem' 
                        }}>
                          電話番号
                        </div>
                        <div style={{ 
                          fontSize: '1.1rem',
                          fontWeight: '500' 
                        }}>
                         {user?.profileData?.phone || '未設定'}
                        </div>
                      </div>
                    </div>

                    {/* アプリ設定見出し */}
                    <div style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginBottom: '1.5rem',
                      paddingBottom: '0.5rem',
                      borderBottom: '1px solid rgba(5, 90, 104, 0.1)'
                    }}>
                      <h4 style={{ 
                        fontSize: '1.1rem', 
                        color: '#055A68', 
                        margin: 0,
                        fontWeight: '600'
                      }}>
                        アプリ設定
                      </h4>
                    </div>

                    {/* 設定情報表示 - カード形式 */}
                    <div style={{
                      backgroundColor: '#f9f9f9',
                      padding: '1.5rem',
                      borderRadius: '12px',
                    }}>
                      {/* 通知設定 */}
                      <div style={{ marginBottom: '1.5rem' }}>
                        <div style={{ 
                          fontSize: '0.85rem', 
                          color: '#055A68', 
                          opacity: 0.8,
                          marginBottom: '0.4rem' 
                        }}>
                          通知
                        </div>
                        <div style={{ 
                          display: 'flex',
                          alignItems: 'center'
                        }}>
                          <div style={{
                            width: '10px',
                            height: '10px',
                            borderRadius: '50%',
                            backgroundColor: user.settings.notifications ? '#4CAF50' : '#ccc',
                            marginRight: '8px'
                          }} />
                          <div style={{ fontSize: '1rem' }}>
                          {user?.settings?.notifications ? '有効' : '無効'}
                          </div>
                        </div>
                      </div>

                      {/* レポート頻度 */}
                      <div>
                        <div style={{ 
                          fontSize: '0.85rem', 
                          color: '#055A68', 
                          opacity: 0.8,
                          marginBottom: '0.4rem' 
                        }}>
                          レポート頻度
                        </div>
                        <div style={{ 
                          fontSize: '1.1rem',
                          fontWeight: '500',
                          display: 'flex',
                          alignItems: 'center'
                        }}>
                          <span style={{
                            display: 'inline-block',
                            padding: '0.3rem 0.8rem',
                            backgroundColor: '#055A6822',
                            borderRadius: '16px',
                            fontSize: '0.9rem',
                            color: '#055A68',
                            fontWeight: '500'
                          }}>
                            {user.settings.reportFrequency === 'daily'
                              ? '毎日'
                              : user.settings.reportFrequency === 'weekly'
                              ? '毎週'
                              : '毎月'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* ログアウトボタン - 表示モードの場合のみ表示 */}
            {!editMode && (
              <button
                onClick={handleLogout}
                className="btn"
                style={{
                  width: '100%',
                  padding: '1rem',
                  backgroundColor: '#f0f0f0',
                  color: '#d32f2f',
                  border: '1px solid #d32f2f',
                  borderRadius: '12px',
                  fontSize: '1rem',
                  fontWeight: '600',
                  cursor: 'pointer',
                  marginBottom: '2rem',
                  transition: 'all 0.3s ease',
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}
              >
                <svg 
                  width="18" 
                  height="18" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor"
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                  <polyline points="16 17 21 12 16 7" />
                  <line x1="21" y1="12" x2="9" y2="12" />
                </svg>
                ログアウト
              </button>
            )}
          </>
        )}
      </div>

      {/* フッターナビゲーション */}
      <MainFooterNav />
    </div>
  );
};

export default ProfilePage;