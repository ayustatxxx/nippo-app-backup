import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import Header from '../components/Header';
import AiSidebar from '../components/AiSidebar';
import useLocalStorage from '../hooks/useLocalStorage';
import { Post } from '../types';

// メッセージの型定義
interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

// アイコンコンポーネント
const Icons = {
  User: () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
      <circle cx="12" cy="7" r="4"></circle>
    </svg>
  ),
  Bot: () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect x="3" y="11" width="18" height="10" rx="2"></rect>
      <circle cx="12" cy="5" r="2"></circle>
      <path d="M12 7v4"></path>
      <line x1="8" y1="16" x2="8" y2="16"></line>
      <line x1="16" y1="16" x2="16" y2="16"></line>
    </svg>
  ),
  Send: () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="22" y1="2" x2="11" y2="13"></line>
      <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
    </svg>
  ),
  Chat: () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="48"
      height="48"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
    </svg>
  ),
};

// 時刻フォーマット関数
const formatTime = (date: Date): string => {
  return date.toLocaleTimeString('ja-JP', {
    hour: '2-digit',
    minute: '2-digit',
  });
};

const AiAnalysisPage: React.FC = () => {
  const { groupId } = useParams<{ groupId: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // 状態管理
const [messages, setMessages] = useState<Message[]>([]);
const [input, setInput] = useState('');
const [isLoading, setIsLoading] = useState(false);
const [posts, setPosts] = useState<Post[]>([]);

// サイドバー関連の状態を追加
const [showSidebar, setShowSidebar] = useState(false);

// 履歴管理を追加
interface HistoryItem {
  date: string;
  query: string;
}
const [history, setHistory] = useLocalStorage<HistoryItem[]>('aiAnalysisHistory', []);
  
  // レファレンス
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // 自動スクロール
const scrollToBottom = () => {
  messagesEndRef.current?.scrollIntoView({ 
    behavior: 'smooth',
    block: 'end',
    inline: 'nearest'
  });
};

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // 投稿データの取得
  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const request = indexedDB.open('daily-report-db');
        
        request.onsuccess = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          const transaction = db.transaction('posts', 'readonly');
          const store = transaction.objectStore('posts');
          const getAllRequest = store.getAll();
          
          getAllRequest.onsuccess = () => {
            const allPosts = getAllRequest.result as Post[];
            const groupPosts = groupId 
              ? allPosts.filter(post => post.groupId === groupId)
              : allPosts;
            setPosts(groupPosts);
          };
          
          transaction.oncomplete = () => db.close();
        };
      } catch (error) {
        console.error('投稿データの取得に失敗:', error);
      }
    };

    fetchPosts();
    inputRef.current?.focus();
    window.scrollTo(0, 0);
  }, [groupId]);



  // 建材データベース
const MATERIAL_DATABASE = {
  "杉の角材": {
    pattern: /杉の?角材[\s\u3000]*(\d+)×(\d+)×(\d+)m?/gi,
    suppliers: [
      { name: "青山材木店", pricePerUnit: 2800, deliveryNote: "※木曜日 午前中に配送手配可能です。", taxNote: "（税込別）" },
      { name: "恵比寿材木店", pricePerUnit: 2700, deliveryNote: "※金曜日午前便で手配できます！", taxNote: "（税別）" }
    ]
  },
  "針葉樹合板": {
    pattern: /針葉樹合板[\s\u3000]*(\d+)mm/gi,
    suppliers: [
      { name: "青山材木店", pricePerUnit: 1450, deliveryNote: "※木曜日 午前中に配送手配可能です。", taxNote: "（税込別）" },
      { name: "恵比寿材木店", pricePerUnit: 1380, deliveryNote: "※金曜日午前便で手配できます！", taxNote: "（税別）" }
    ]
  },
  "石膏ボード": {
    pattern: /石膏ボード[\s\u3000]*(\d+\.?\d*)mm[\s\u3000]*(\d+)×(\d+)/gi,
    suppliers: [
      { name: "青山材木店", pricePerUnit: 980, deliveryNote: "※木曜日 午前中に配送手配可能です。", taxNote: "（税込別）" },
      { name: "恵比寿材木店", pricePerUnit: 950, deliveryNote: "※金曜日午前便で手配できます！", taxNote: "（税別）" }
    ]
  }
};

// 建材注文パターンを検出・解析する関数
const detectMaterialOrder = (message: string) => {
  console.log("入力メッセージ:", message);
  
  const orders = [];
  
  // より柔軟な分割方法
  const parts = message.split(/[・\n]/);
  
  console.log("分割された行:", parts);
  
  for (const part of parts) {
    const line = part.trim();
    if (!line) continue;
    
    console.log("現在処理中の行:", line);
    
    // 各建材タイプをチェック
    for (const [materialType, config] of Object.entries(MATERIAL_DATABASE)) {
      const materialMatch = line.match(config.pattern);
      console.log(`${materialType}のマッチ結果:`, materialMatch);
      
      if (materialMatch) {
        // より幅広い数量パターンで検索
        const quantityPatterns = [
          /→\s*(\d+)\s*(?:本|枚)/g,
          /(\d+)\s*(?:本|枚)/g
        ];
        
        let quantity = null;
        
        for (const pattern of quantityPatterns) {
          pattern.lastIndex = 0; // グローバルパターンをリセット
          const quantityMatch = pattern.exec(line);
          console.log("数量マッチ結果:", quantityMatch);
          
          if (quantityMatch) {
            quantity = parseInt(quantityMatch[1]);
            console.log("検出された数量:", quantity);
            break;
          }
        }
        
        if (quantity && quantity > 0) {
          console.log("追加される注文:", { type: materialType, quantity });
          orders.push({
            type: materialType,
            description: line,
            quantity,
            suppliers: config.suppliers
          });
        }
      }
    }
  }
  
  console.log("最終的な注文リスト:", orders);
  return orders;
};

// 見積もりを生成する関数
const generateQuote = (orders: any[], originalQuestion: string) => {
  if (orders.length === 0) return null;
  
  const suppliers = orders[0].suppliers;
  
  // 元の質問から金曜日をチェック
  const hasDeadline = /金曜日/.test(originalQuestion);

  let quoteText = hasDeadline 
    ? `こちらの商品が、金曜日までにお届け可能な建材屋さんはこちら\n-------------------------------\n`
    : `お見積もり結果をご案内いたします\n-------------------------------\n`;
  
  suppliers.forEach((supplier, index) => {
    quoteText += `${supplier.name}\n`;
    quoteText += `お見積もりは以下の通りになります\n\n`;
    
    let total = 0;
    
    orders.forEach(order => {
      const supplierData = order.suppliers[index];
      const subtotal = order.quantity * supplierData.pricePerUnit;
      total += subtotal;
      
      const unit = order.type === "杉の角材" ? "本" : "枚";
quoteText += `${order.type}　${order.quantity}${unit} × ${supplierData.pricePerUnit.toLocaleString()}円 ＝ ${subtotal.toLocaleString()}円\n`;
    });
    
    quoteText += `合計：${total.toLocaleString()}円${supplier.taxNote}\n\n`;
    quoteText += `${supplier.deliveryNote}\n`;
    quoteText += `-------------------------------\n`;
    
    if (index < suppliers.length - 1) {
      quoteText += `\n`;
    }
  });
  
  const hasNeedleLeafPlywood = orders.some(order => order.type === "針葉樹合板");
  if (hasNeedleLeafPlywood) {
    quoteText += `\n※ 補足\n`;
    quoteText += `但し、針葉樹合板 12mm → ${orders.find(o => o.type === "針葉樹合板")?.quantity}枚は、貴社の倉庫に在庫としてございますので、そちらから取り寄せることをお勧めします。\n`;
    
  }
  
  return quoteText;
};




const generateAIResponse = (question: string, posts: Post[]) => {
  const questionLower = question.toLowerCase();
  
  // 建材注文パターンをチェック（最優先）
  // 建材注文パターンをチェック（最優先）
const materialOrders = detectMaterialOrder(question);
if (materialOrders.length > 0) {
  return generateQuote(materialOrders, question);
}
  
  // 投稿数と基本情報
  const totalPosts = posts.length;
    const workTimePosts = posts.filter(post => post.isWorkTimePost);
    const regularPosts = posts.filter(post => !post.isWorkTimePost);
    
    // タグ分析
    const allTags = posts.flatMap(post => post.tags || []);
    const tagCounts = allTags.reduce((acc, tag) => {
      acc[tag] = (acc[tag] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    // 最新投稿の情報
    const latestPost = posts[0];
    
    // 質問パターンに応じた回答生成
    if (questionLower.includes('作業時間') || questionLower.includes('勤務') || questionLower.includes('時間')) {
      return `📊 **作業時間分析結果**
      
現在のデータ${totalPosts}件を分析した結果：
• 出退勤記録：${workTimePosts.length}件
• 作業報告：${regularPosts.length}件
• 推定稼働日数：${Math.floor(workTimePosts.length / 2)}日

**AIの分析コメント：**
${latestPost ? `最新の記録（${latestPost.time.split('　')[0]}）では、効率的な作業進行が確認できます。` : ''}作業時間の記録が継続されており、労働時間管理が適切に行われています。

**具体的な改善提案：**
• チェックイン・チェックアウトの記録を毎日継続
• 作業内容の詳細な記録で効率性向上
• 写真付きレポートで現場状況の可視化`;
    }
    
    if (questionLower.includes('効率') || questionLower.includes('生産性') || questionLower.includes('改善')) {
      const topTag = Object.entries(tagCounts).sort(([,a], [,b]) => b - a)[0];
      return `⚡ **作業効率分析結果**
      
データ分析による効率性評価：
• 最も頻繁な作業：${topTag ? `#${topTag[0]} (${topTag[1]}回)` : '出退勤管理'}
• 記録の継続性：${totalPosts > 5 ? '優秀' : '改善の余地あり'}
• データ品質：${posts.filter(p => p.message && p.message.length > 10).length}件の詳細記録

**AI推奨改善策：**
1. 写真付き報告の増加（現状${posts.filter(p => p.photoUrls && p.photoUrls.length > 0).length}件）
2. タグの活用による分類強化
3. 定期的な進捗レビューの実施

**効率化のポイント：**
• 同じ作業パターンの分析と最適化
• 時間のかかる工程の特定と改善
• チーム内での知識共有の促進`;
    }
    
    if (questionLower.includes('コスト') || questionLower.includes('費用') || questionLower.includes('削減')) {
      return `💰 **コスト分析結果**
      
日報データに基づくコスト最適化提案：
• 記録されたデータ量：${totalPosts}件
• 管理工数削減効果：月間約12時間
• 予想年間削減額：約240万円

**具体的な削減ポイント：**
1. デジタル化による事務工数削減：月間8時間
2. リアルタイム進捗把握による手戻り防止：月間4時間
3. データ分析による最適化：継続的な改善効果

**コスト削減の実現方法：**
• 紙ベースの日報管理からの脱却
• 現場と事務所間の情報共有効率化
• 予実管理の精度向上による無駄の排除

${latestPost ? `最新の投稿内容「${latestPost.message.substring(0, 50)}...」からも、効率的な作業進行が確認できます。` : ''}`;
    }
    
    if (questionLower.includes('問題') || questionLower.includes('課題') || questionLower.includes('トラブル')) {
      return `⚠️ **課題・問題分析結果**
      
投稿データから検出された注意点：
• 未確認投稿：${posts.filter(p => p.status === '未確認').length}件
• 編集された投稿：${posts.filter(p => p.isEdited).length}件
• 写真なし投稿：${posts.filter(p => !p.photoUrls || p.photoUrls.length === 0).length}件

**AIが検出した改善機会：**
1. 投稿確認プロセスの迅速化
2. 現場写真添付率の向上
3. リアルタイム状況共有の強化

**解決に向けたアクション：**
• 管理者による投稿確認の定期化
• 写真撮影の習慣化と品質向上
• 緊急時の連絡体制整備

継続的なデータ蓄積により、より精密な問題予測が可能になります。`;
    }
    
    if (questionLower.includes('進捗') || questionLower.includes('状況') || questionLower.includes('現状')) {
      const recentPosts = posts.slice(0, 3);
      return `📈 **プロジェクト進捗分析**
      
現在の状況サマリー：
• 総投稿数：${totalPosts}件
• 直近の活動：${recentPosts.length}件の報告
• アクティブ度：${totalPosts > 10 ? '高' : totalPosts > 5 ? '中' : '低'}

**最新の動き：**
${recentPosts.map((post, i) => 
  `${i + 1}. ${post.time.split('　')[0]}：${post.message.substring(0, 40)}...`
).join('\n')}

**AIの総合評価：**
プロジェクトは${totalPosts > 10 ? '順調に' : '着実に'}進行中。継続的な記録により、品質管理と進捗把握が効果的に行われています。

**今後の推奨事項：**
• データ蓄積の継続
• 定期的なレビューの実施
• チーム内コミュニケーションの活性化`;
    }
    
    // デフォルト回答
    return `🤖 **AI分析レポート**
    
ご質問「${question}」について、現在のデータ${totalPosts}件を分析しました。

**データサマリー：**
• 投稿総数：${totalPosts}件
• 作業記録：${workTimePosts.length}件
• 報告投稿：${regularPosts.length}件
• 使用タグ：${Object.keys(tagCounts).length}種類

**AI判断：**
データが継続的に蓄積されており、デジタル化による業務効率向上が実現されています。より具体的な質問をいただければ、詳細な分析をご提供できます。

**推奨する質問例：**
• 「作業効率はどうですか？」
• 「コスト削減効果を教えて」
• 「現在の問題点は？」
• 「進捗状況を分析して」`;
  };

  // メッセージ送信処理
  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input;
    const messageId = Date.now().toString();

    // ユーザーメッセージを追加
    const newUserMessage: Message = {
      id: messageId,
      text: userMessage,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // 2秒の待機でAI処理をシミュレート
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const response = generateAIResponse(userMessage, posts);
      
      const aiMessage: Message = {
        id: messageId + '-reply',
        text: response,
        sender: 'ai',
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: messageId + '-error',
        text: '申し訳ございません。分析中にエラーが発生しました。再度お試しください。',
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  };

  // キーボードイベント
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // 戻るボタンの処理
  const handleBack = () => {
    const from = searchParams.get('from');
    const postId = searchParams.get('postId');

    const params = new URLSearchParams();
    if (from) params.set('from', from);
    if (postId) params.set('postId', postId);
    const paramString = params.toString() ? `?${params.toString()}` : '';

    navigate(`/group/${groupId}/archive${paramString}`);
  };


  // サイドバー関連の関数
const toggleSidebar = () => {
  setShowSidebar(!showSidebar);
};

const applyPrompt = (prompt: string) => {
  setInput(prompt);
  inputRef.current?.focus();
  
  // 履歴に追加
  const today = new Date().toLocaleDateString('ja-JP');
  setHistory([{ date: today, query: prompt }, ...history].slice(0, 10));
  
  // モバイルの場合はサイドバーを閉じる
  if (window.innerWidth <= 768) {
    setShowSidebar(false);
  }
};




  // 提案質問の適用
  const applySuggestion = (suggestion: string) => {
    setInput(suggestion);
    inputRef.current?.focus();
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      backgroundColor: '#f5f5f5',
      paddingBottom: '100px',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* サイドバーを追加 */}
      <AiSidebar 
        showSidebar={showSidebar}
        toggleSidebar={toggleSidebar}
        applyPrompt={applyPrompt}
      />
      
      {/* サイドバー開閉ボタン */}
      {!showSidebar && (
  <button
    onClick={toggleSidebar}
    style={{
      position: 'fixed',
      top: '70px',
      left: '10px',
      backgroundColor: '#055A68',
      color: 'white',
      border: 'none',
      borderRadius: '6px',
      padding: '8px',
      cursor: 'pointer',
      zIndex: 1000,
      fontSize: '18px',
      width: '40px',
      height: '40px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
    }}
  >
    ≡
  </button>
)}
  
      {/* ヘッダー */}
      <Header 
        title={
          <span style={{ letterSpacing: "0.05em" }}>
            AI分析 
            <span style={{ 
              fontSize: '0.8em', 
              fontWeight: 'normal', 
              opacity: 0.7,
              marginLeft: '0.3em'
            }}>
              ({posts.length}件)
            </span>
          </span>
        } 
        showBackButton={true}
        onBackClick={handleBack}
      />


      
      {/* ヘッダー */}
      <Header 
  title={
    <span style={{ letterSpacing: "0.05em" }}>
      AI分析 
      <span style={{ 
        fontSize: '0.6em', 
        fontWeight: 'bold', 
        opacity: 0.8,
        marginLeft: '0.8em'
      }}>
        ({posts.length}件)
      </span>
    </span>
  } 
  showBackButton={true}
  onBackClick={handleBack}
/>
      
      {/* チャットエリア（フルスクリーン） */}
      <div style={{ 
        flex: 1,
        paddingTop: '120px',
        paddingLeft: '1rem',
        paddingRight: '1rem',
        maxWidth: '480px', 
        margin: '0 auto',
        width: '100%',
        boxSizing: 'border-box'
      }}>
        {/* 空の状態 */}
        {messages.length === 0 && (
          <div style={{ 
            textAlign: 'center', 
            padding: '2rem 1rem', 
            color: '#666',
            backgroundColor: 'white',
            borderRadius: '12px',
            margin: '1rem 0',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
          }}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>
              <Icons.Chat />
            </div>
            <h3 style={{ 
              color: '#055A68', 
              marginBottom: '0.5rem',
              fontSize: '1.2rem'
            }}>
              AI分析アシスタント
            </h3>
            <p style={{ 
              fontSize: '0.9rem', 
              marginBottom: '1.5rem',
              color: '#666'
            }}>
              投稿データ（{posts.length}件）について、AIに質問できます
            </p>
            
            {/* 提案質問ボタン */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {[
                '作業効率はどうですか？',
                'コスト削減効果を教えて',
                '現在の問題点は？',
                '進捗状況を分析して'
              ].map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => applySuggestion(suggestion)}
                  style={{
                    padding: '0.75rem 1rem',
                    backgroundColor: 'rgba(5, 90, 104, 0.05)',
                    color: '#055A68',
                    border: '1px solid rgba(5, 90, 104, 0.2)',
                    borderRadius: '8px',
                    fontSize: '0.9rem',
                    cursor: 'pointer',
                    transition: 'all 0.3s',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = 'rgba(5, 90, 104, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'rgba(5, 90, 104, 0.05)';
                  }}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* メッセージ一覧 */}
        {messages.map((message) => (
          <div
            key={message.id}
            style={{
              display: 'flex',
              marginBottom: '1rem',
              alignItems: 'flex-start',
              flexDirection: message.sender === 'user' ? 'row-reverse' : 'row',
            }}
          >
            {/* アバター */}
            <div
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '50%',
                backgroundColor: message.sender === 'user' ? 'rgba(5, 90, 104, 0.1)' : 'rgba(5, 90, 104, 0.1)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                margin: message.sender === 'user' ? '0 0 0 0.5rem' : '0 0.5rem 0 0',
                flexShrink: 0,
              }}
            >
              {message.sender === 'user' ? <Icons.User /> : <Icons.Bot />}
            </div>

            {/* メッセージ内容 */}
            <div style={{ flex: 1, maxWidth: '85%' }}>
              <div
                style={{
                  backgroundColor: message.sender === 'user' 
                    ? 'rgba(5, 90, 104, 0.1)' 
                    : 'white',
                  padding: '0.75rem',
                  borderRadius: '12px',
                  color: '#333',
                  fontSize: '0.9rem',
                  lineHeight: '1.5',
                  whiteSpace: 'pre-line',
                  border: message.sender === 'user' 
                    ? '1px solid rgba(5, 90, 104, 0.2)' 
                    : '1px solid #e0e0e0',
                  boxShadow: message.sender === 'ai' ? '0 2px 8px rgba(0, 0, 0, 0.1)' : 'none',
                }}
              >
                {message.text}
              </div>
              <div
                style={{
                  fontSize: '0.75rem',
                  color: '#999',
                  marginTop: '0.25rem',
                  textAlign: message.sender === 'user' ? 'right' : 'left',
                }}
              >
                {formatTime(message.timestamp)}
              </div>
            </div>
          </div>
        ))}

        {/* ローディング表示 */}
        {isLoading && (
          <div style={{ display: 'flex', alignItems: 'flex-start', marginBottom: '1rem' }}>
            <div
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '50%',
                backgroundColor: 'rgba(5, 90, 104, 0.1)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                marginRight: '0.5rem',
              }}
            >
              <Icons.Bot />
            </div>
            <div
              style={{
                backgroundColor: 'white',
                padding: '0.75rem',
                borderRadius: '12px',
                border: '1px solid #e0e0e0',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
              }}
            >
              <div style={{ display: 'flex', gap: '0.3rem', alignItems: 'center' }}>
                <div
                  style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    backgroundColor: '#055A68',
                    animation: 'bounce 1.4s ease-in-out infinite both',
                    animationDelay: '0s',
                  }}
                />
                <div
                  style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    backgroundColor: '#055A68',
                    animation: 'bounce 1.4s ease-in-out infinite both',
                    animationDelay: '0.16s',
                  }}
                />
                <div
                  style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    backgroundColor: '#055A68',
                    animation: 'bounce 1.4s ease-in-out infinite both',
                    animationDelay: '0.32s',
                  }}
                />
              </div>
            </div>
          </div>
        )}

<div ref={messagesEndRef} style={{ height: '80px' }} />
      </div>

      {/* 固定入力エリア */}
      <div style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        width: '100%',
        backgroundColor: 'white',
        borderTop: '1px solid #e0e0e0',
        boxShadow: '0 -2px 10px rgba(0, 0, 0, 0.1)',
        zIndex: 1000,
      }}>
        <div style={{
          maxWidth: '480px',
          margin: '0 auto',
          padding: '1rem',
        }}>
          <div style={{
            display: 'flex',
            gap: '0.5rem',
            alignItems: 'flex-end',
          }}>
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="例：作業効率はどうですか？"
              disabled={isLoading}
              style={{
                flex: 1,
                backgroundColor: '#f8f9fa',
                border: '1px solid #ddd',
                borderRadius: '20px',
                padding: '0.75rem 1rem',
                color: '#333',
                fontSize: '0.9rem',
                outline: 'none',
                transition: 'border-color 0.3s',
              }}
              onFocus={(e) => e.target.style.borderColor = '#055A68'}
              onBlur={(e) => e.target.style.borderColor = '#ddd'}
            />
            <button
              onClick={handleSend}
              disabled={isLoading || !input.trim()}
              style={{
                backgroundColor: input.trim() && !isLoading ? '#055A68' : '#ccc',
                color: 'white',
                border: 'none',
                borderRadius: '50%',
                width: '44px',
                height: '44px',
                cursor: input.trim() && !isLoading ? 'pointer' : 'not-allowed',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'background-color 0.3s',
              }}
              >
              <div style={{ 
  fontSize: '1.4em',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center'
}}>
  <Icons.Send />
</div>
            </button>
          </div>
        </div>
      </div>

      <style>
        {`
          @keyframes bounce {
            0%, 80%, 100% { 
              transform: scale(0);
              opacity: 0.5;
            } 
            40% { 
              transform: scale(1);
              opacity: 1;
            }
          }
        `}
      </style>
    </div>
  );
};

export default AiAnalysisPage;