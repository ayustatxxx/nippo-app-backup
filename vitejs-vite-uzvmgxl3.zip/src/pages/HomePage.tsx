import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import MainFooterNav from '../components/MainFooterNav';
import Header from '../components/Header';
import { User, Group } from './types';
import { DBUtil, STORES } from "../utils/dbUtil";
import { getGroups, getUserGroups } from "../utils/dbUtil";
import { Post } from '../types';
import ImageGalleryModal from '../components/ImageGalleryModal';
import { getCurrentUser, isAdmin, getUserRole } from '../utils/authUtil'; // getUserRoleを追加

// ★自分の画像用の設定を追加★
const MY_IMAGE_BASE_URL = 'https://ayustatxxx.github.io/my-construction-images/images/';

const MY_IMAGES = [
  `${MY_IMAGE_BASE_URL}construction1.jpg`,
  `${MY_IMAGE_BASE_URL}construction2.jpg`,
  `${MY_IMAGE_BASE_URL}construction3.jpg`,
  `${MY_IMAGE_BASE_URL}construction4.jpg`,
  `${MY_IMAGE_BASE_URL}construction5.jpg`,
  `${MY_IMAGE_BASE_URL}construction6.jpg`,
  `${MY_IMAGE_BASE_URL}construction7.jpg`,
  `${MY_IMAGE_BASE_URL}construction8.jpg`,
  `${MY_IMAGE_BASE_URL}construction9.jpg`,
  `${MY_IMAGE_BASE_URL}construction10.jpg`,
  `${MY_IMAGE_BASE_URL}construction11.jpg`,
  `${MY_IMAGE_BASE_URL}construction12.jpg`,
  `${MY_IMAGE_BASE_URL}construction13.jpg`,
  `${MY_IMAGE_BASE_URL}construction14.jpg`,
];

// アラート情報の型定義
interface AlertInfo {
  id: string;
  userId: string;
  username: string;
  groupId: string;
  groupName: string;
  deadline: string;
  timestamp: number;
  type: 'alert';
}

// タイムライン項目の共通型（投稿またはアラート）
type TimelineItem = Post | AlertInfo;

// カードコンポーネント用のプロパティ
interface PostCardProps {
  post: Post;
  onViewDetails: (postId: string, groupId: string) => void;
  onImageClick: (imageUrl: string, allImages: string[]) => void;
  navigate: (path: string) => void;
  onStatusUpdate: (postId: string, newStatus: string) => void;
  getContainerStatusStyle: (status: string) => any;
  userRole: 'admin' | 'user'; // この行を追加
}

// 未投稿アラートカード用のプロパティ
interface AlertCardProps {
  alert: AlertInfo;
  onContact: (groupId: string) => void;
  navigate: (path: string) => void;
}

// PostCardコンポーネント
const PostCard: React.FC<PostCardProps> = ({ 
  post, 
  onViewDetails, 
  onImageClick, 
  navigate, 
  onStatusUpdate, 
  getContainerStatusStyle,
  userRole  
}) => {
  const [selectedPostForStatus, setSelectedPostForStatus] = useState<string | null>(null); 

  return (
    <div
      key={post.id}
      style={{
        backgroundColor: '#E6EDED',
        color: 'rgb(0, 102, 114)',
        borderRadius: '12px',
        padding: '1rem',
        marginBottom: '1rem',
        boxShadow: '0 4px 6px rgba(0, 102, 114, 0.1), 0 1px 3px rgba(0, 102, 114, 0.08)',
        border: '1px solid rgba(0, 102, 114, 0.1)',
        transition: 'box-shadow 0.3s ease',
      }}
    >
      {/* ヘッダー部分: 投稿者アイコン、名前、グループ名と時間 */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'flex-start',
        marginBottom: '0.8rem' 
      }}>
        {/* 投稿者名とアバター - 左側に配置 */}
        <div style={{ 
          display: 'flex', 
          alignItems: 'center'
        }}>
          <div style={{ 
            width: '32px', 
            height: '32px', 
            borderRadius: '50%', 
            backgroundColor: 'rgba(0, 102, 114, 0.1)',
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center', 
            marginRight: '0.5rem' 
          }}>
            <svg 
              width="18" 
              height="18" 
              viewBox="0 0 24 24" 
              fill="rgb(0, 102, 114)" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M12 12C14.21 12 16 10.21 16 8C16 5.79 14.21 4 12 4C9.79 4 8 5.79 8 8C8 10.21 9.79 12 12 12ZM12 14C9.33 14 4 15.34 4 18V20H20V18C20 15.34 14.67 14 12 14Z" />
            </svg>
          </div>
          <div style={{ fontWeight: 'bold', fontSize: '0.95rem' }}>
            {post.username || 'ユーザー'}
          </div>
        </div>
        
        {/* プロジェクト名と時間を縦に配置 - 右側に配置 */}
        <div style={{ 
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-end',
          gap: '0.2rem'
        }}>
          {/* グループ名をクリック可能にして、グループTOPページに遷移 */}
          <div 
            style={{ 
              fontSize: '0.85rem', 
              color: '#055A68',
              cursor: 'pointer',
              textDecoration: 'none',
              transition: 'color 0.2s ease',
            }}
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/group/${post.groupId}?from=home&postId=${post.id}`);
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.color = '#033E4A';
              e.currentTarget.style.textDecoration = 'underline';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.color = '#055A68';
              e.currentTarget.style.textDecoration = 'none';
            }}
          >
            {post.groupName || 'グループ名なし'}
          </div>
          
          <div
            style={{
              fontWeight: '500',
              fontSize: '0.85rem',
              color: '#055A68',
            }}
          >
            {extractTime(post.time)}
          </div>
        </div>
      </div>
      
      {/* 区切り線 */}
      <div 
        style={{
          height: '1px',
          backgroundColor: 'rgba(0, 102, 114, 0.3)',
          marginBottom: '0.8rem',
        }}
      />

      {/* 投稿メッセージ - 120文字制限と「more」ボタン追加 */}
      {post.message && post.message.length > 0 && (
        <div
          style={{
            marginBottom: '0.8rem',
            whiteSpace: 'pre-wrap',
            lineHeight: '1.5',
            fontSize: '0.95rem',
            color: '#055A68',
          }}
        >
          {/* メッセージが120文字より長い場合は省略表示 */}
          {post.message.length > 120 
            ? (
              <div>
                {`${post.message.substring(0, 120)}...`}
                {post.isEdited && (
                  <span style={{
                    color: 'rgba(5, 90, 104, 0.8)',
                    fontSize: '0.8rem',
                    marginLeft: '0.5rem'
                  }}>
                    （編集済み）
                  </span>
                )}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onViewDetails(post.id, post.groupId);
                  }}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: '#055A68',
                    fontWeight: 'bold',
                    fontSize: '0.85rem',
                    padding: '0.2rem 0',
                    cursor: 'pointer',
                    textDecoration: 'underline',
                    marginTop: '0.3rem',
                    display: 'block',
                  }}
                >
                  more
                </button>
              </div>
            ) 
            : (
              <div>
                {post.message}
                {post.isEdited && (
                  <span style={{
                    color: 'rgba(5, 90, 104, 0.8)',
                    fontSize: '0.8rem',
                    marginLeft: '0.5rem'
                  }}>
                    （編集済み）
                  </span>
                )}
              </div>
            )
          }
        </div>
      )}

      {/* メッセージがない場合の編集済み表示 */}
      {(!post.message || post.message.length === 0) && post.isEdited && (
        <div style={{
          marginBottom: '0.8rem',
          color: 'rgba(5, 90, 104, 0.8)',
          fontSize: '0.8rem',
          fontStyle: 'italic'
        }}>
          （編集済み）
        </div>
      )}

      {/* タグ表示 */}
      {post.tags && post.tags.length > 0 && (
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '0.5rem',
            marginBottom: '0.8rem',
          }}
        >
          {post.tags.slice(0, 3).map((tag, index) => (
            <span
              key={index}
              style={{
                backgroundColor: 'rgba(0, 102, 114, 0.1)',
                color: 'rgb(0, 102, 114)',
                padding: '0.25rem 0.7rem',
                borderRadius: '999px',
                fontSize: '0.75rem',
                fontWeight: '800',
              }}
            >
              {tag}
            </span>
          ))}
          {post.tags.length > 3 && (
            <span
              style={{
                backgroundColor: 'rgba(0, 102, 114, 0.05)',
                color: 'rgb(0, 102, 114)',
                padding: '0.25rem 0.7rem',
                borderRadius: '999px',
                fontSize: '0.75rem',
              }}
            >
              +{post.tags.length - 3}
            </span>
          )}
        </div>
      )}

      {/* 写真のサムネイル表示 - 最大2段7枚+「+X」表示に変更 */}
      {post.photoUrls && post.photoUrls.length > 0 && (
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '0.5rem',
            marginBottom: '0.5rem',
          }}
        >
          {/* 写真サムネイル表示（最大7枚まで表示、8枚以上で+X表示） */}
          {post.photoUrls.slice(0, Math.min(7, post.photoUrls.length)).map((url, index) => (
            <div
              key={index}
              style={{
                width: 'calc((100% - 1.5rem) / 4)',
                aspectRatio: '1/1',
                borderRadius: '8px',
                overflow: 'hidden',
                marginTop: index >= 4 ? '0.5rem' : '0',
                cursor: 'pointer',
              }}
              onClick={(e) => {
                e.stopPropagation();
                onImageClick(url, post.photoUrls);
              }}
            >
              <img
                src={url}
                alt={`投稿画像 ${index + 1}`}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                }}
                loading="lazy"
              />
            </div>
          ))}
          
          {/* 8枚以上ある場合、最後の枠に+X表示 - こちらも詳細ページに遷移 */}
          {post.photoUrls.length > 7 && (
            <div
              style={{
                width: 'calc((100% - 1.5rem) / 4)',
                aspectRatio: '1/1',
                borderRadius: '8px',
                backgroundColor: 'rgba(0, 102, 114, 0.1)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                color: 'rgb(0, 102, 114)',
                fontSize: '1.1rem',
                fontWeight: 'bold',
                marginTop: '0.5rem',
                cursor: 'pointer',
              }}
              onClick={(e) => {
                e.stopPropagation();
                onImageClick(post.photoUrls[0], post.photoUrls);
              }}
            >
              +{post.photoUrls.length - 7}
            </div>
          )}
        </div>
      )}
      {!post.isWorkTimePost && (
  <>
    {/* 区切り線 */}
    <div 
  style={{
    height: '1px',
    backgroundColor: 'rgba(0, 102, 114, 0.2)',
    marginTop: '1rem',
    marginBottom: '0.8rem',
  }}
/>
    
    {/* ステータスと詳細ボタンのコンテナ */}
   <div
  style={{
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  }}
>
 {/* 左側 - ステータス（管理者のみ表示） */}
{userRole === 'admin' && (
  <div>
    <span 
      style={getContainerStatusStyle(post.status || '未確認')} 
      onClick={(e) => {
        e.stopPropagation();
        setSelectedPostForStatus(post.id);
      }}
      onMouseEnter={(e) => e.currentTarget.style.opacity = '0.8'}
      onMouseLeave={(e) => e.currentTarget.style.opacity = '1'}
    >
      {post.status || '未確認'}
    </span>
  </div>
)}

            {/* 右側 - 詳細ボタン */}
            <div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onViewDetails(post.id, post.groupId);
                }}
                style={{
                  padding: '0.4rem 1.2rem',
                  backgroundColor: 'rgb(0, 102, 114)',
                  color: '#F0DB4F',
                  border: 'none',
                  borderRadius: '20px',
                  fontSize: '0.8rem',
                  cursor: 'pointer',
                  fontWeight: 'bold',
                  transition: 'opacity 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.opacity = '0.8'}
                onMouseLeave={(e) => e.currentTarget.style.opacity = '1'}
              >
                詳細
              </button>
            </div>
          </div>
        </>
      )}

      {/* ★ ステータス選択モーダル ★ */}
      {selectedPostForStatus === post.id && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000,
            padding: '1rem',
          }}
          onClick={() => setSelectedPostForStatus(null)}
        >
          <div
            style={{
              backgroundColor: '#ffffff',
              borderRadius: '20px',
              width: '100%',
              maxWidth: '320px',
              padding: '1.5rem',
              boxShadow: '0 20px 40px rgba(0, 0, 0, 0.3)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <h3 style={{
              margin: '0 0 1.5rem 0',
              color: '#055A68',
              fontSize: '1.2rem',
              fontWeight: '600',
              textAlign: 'center'
            }}>
              ステータスを選択
            </h3>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
              {['未確認', '確認済み'].map(status => (
                <button
                  key={status}
                  onClick={() => {
                    onStatusUpdate(post.id, status);
                    setSelectedPostForStatus(null);
                  }}
                  style={{
                    padding: '0.8rem 0.8rem',
                    borderRadius: '15px',
                    fontSize: '0.9rem',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'opacity 0.2s',
                    border: 'none',
                    outline: 'none',
                    backgroundColor: status === '確認済み' ? '#1f5b91' : '#ff6b6b',
                    color: 'white',
                    textAlign: 'center',
                    width: '100%',
                    opacity: (post.status || '未確認') === status ? 0.5 : 1
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.opacity = '0.6'}
                  onMouseLeave={(e) => {
                    const currentStatus = post.status || '未確認';
                    e.currentTarget.style.opacity = currentStatus === status ? '0.5' : '1';
                  }}
                >
                  {status}
                </button>
              ))}
            </div>
            
            <button
              onClick={() => setSelectedPostForStatus(null)}
              style={{
                width: '100%',
                marginTop: '1.5rem',
                padding: '0.7rem',
                backgroundColor: '#d6d6d6',
                color: 'black',
                border: 'none',
                borderRadius: '15px',
                fontSize: '0.9rem',
                cursor: 'pointer'
              }}
            >
              キャンセル
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// 未投稿アラートカードコンポーネント
const AlertCard: React.FC<AlertCardProps> = ({ alert, onContact, navigate }) => {
  return (
    <div
    style={{
      backgroundColor: '#F4F1DF',
      color: 'rgb(0, 102, 114)',
      borderRadius: '12px',
      padding: '1rem',
      marginBottom: '1rem',
      cursor: 'default',
      position: 'relative',
      paddingBottom: '3rem',
      boxShadow: '0 4px 6px rgba(0, 102, 114, 0.1), 0 1px 3px rgba(0, 102, 114, 0.08)',
      border: '1px solid rgba(0, 102, 114, 0.1)',
    }}
    >
      {/* ユーザー名とグループ名のヘッダー - 位置を入れ替え */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        marginBottom: '0.5rem',
        fontSize: '0.8rem',
        color: '#055A68'
      }}>
        {/* ユーザー名を左側に配置 */}
        <div>{alert.username}</div>
        {/* グループ名を右側に配置 - クリック可能に */}
        <div 
          style={{ 
            cursor: 'pointer',
            color: '#055A68',
            transition: 'color 0.2s ease',
          }}
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/group/${alert.groupId}?from=home`);
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = '#033E4A';
            e.currentTarget.style.textDecoration = 'underline';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = '#055A68';
            e.currentTarget.style.textDecoration = 'none';
          }}
        >
          {alert.groupName}
        </div>
      </div>
      
      {/* アラート表示 */}
      <div style={{ 
        color: 'rgb(0, 102, 114)',
        fontWeight: 'bold', 
        marginBottom: '0.5rem',
        display: 'flex',
        alignItems: 'center',
        gap: '0.4rem'
      }}>
        <span>⚠️</span>
        未投稿アラート
      </div>
      
      <div style={{ 
        color: 'rgb(0, 102, 114)', 
        fontSize: '0.95rem' 
      }}>
        <span style={{ fontWeight: 'bold' }}>{alert.username}</span>さんが
        <span style={{ fontWeight: 'bold' }}>{alert.groupName}</span>に
        投稿していません
      </div>
      
      <div style={{ 
        color: '#055A68', 
        fontSize: '0.85rem', 
        marginTop: '0.5rem'
      }}>
        締切時間: {alert.deadline}
      </div>
      
      {/* 連絡するボタン */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onContact(alert.groupId);
        }}
        style={{
          backgroundColor: '#F0DB4F',
          color: 'rgb(0, 102, 114)', 
          border: '1px solid rgb(0, 102, 114)',
          borderRadius: '20px',
          padding: '0.4rem 0.8rem',
          fontSize: '0.85rem',
          fontWeight: 'bold',
          cursor: 'pointer',
          position: 'absolute',
          bottom: '1rem',
          right: '1rem',
          transition: 'background-color 0.3s ease',
        }}
      >
        連絡する
      </button>
    </div>
  );
};

// 3. ユーティリティ関数
// 時間部分のみを抽出する関数
const extractTime = (dateTimeStr: string): string => {
  const parts = dateTimeStr.split('　');
  if (parts.length > 1) {
    return parts[1];
  }
  return dateTimeStr;
};

// 日本語形式の日付文字列からDateオブジェクトを作成する関数
const parseDateString = (dateTimeStr: string): Date => {
  try {
    const [datePart, timePart] = dateTimeStr.split('　');
    const dateWithoutWeekday = datePart.replace(/（.+）/, '');
    const formattedDate = dateWithoutWeekday
      .replace(/\s+/g, '')
      .replace(/\//g, '-');
    const dateTimeString = `${formattedDate} ${timePart}`;
    return new Date(dateTimeString);
  } catch (e) {
    console.error('日付解析エラー:', dateTimeStr, e);
    return new Date();
  }
};

// 締め切り時間を確認する関数
const isDeadlinePassed = (deadline: string, today: Date): boolean => {
  try {
    const [hours, minutes] = deadline.split(':').map(Number);
    const deadlineDate = new Date(today);
    deadlineDate.setHours(hours, minutes, 0, 0);
    return new Date() > deadlineDate;
  } catch (e) {
    console.error('締め切り時間の解析エラー:', deadline, e);
    return false;
  }
};

// 日付のフォーマット関数
const formatDate = (date: Date) => {
  const y = date.getFullYear();
  const m = date.getMonth() + 1;
  const d = date.getDate();
  const weekdays = ["日", "月", "火", "水", "木", "金", "土"];
  const w = weekdays[date.getDay()];
  
  return `${y} / ${m} / ${d}（${w}）`;
};

// 時間のフォーマット関数
const formatTime = (date: Date) => {
  const h = date.getHours().toString().padStart(2, '0');
  const min = date.getMinutes().toString().padStart(2, '0');
  return `${h}:${min}`;
};

// 未投稿アラートを取得する関数
const getMissingPostAlerts = async (groups: Group[]): Promise<AlertInfo[]> => {
  try {
    if (groups.length === 0) {
      return [];
    }
    
    const now = Date.now();
    const alerts: AlertInfo[] = [];
    
    // 最小限のアラート生成（処理時間短縮）
    alerts.push({
      id: `alert_${now}`,
      userId: "user2",
      username: "鈴木一郎",
      groupId: groups[0].id,
      groupName: groups[0].name,
      deadline: groups[0].reportSettings?.deadline || "18:00",
      timestamp: now,
      type: 'alert'
    });
    
    // 2つ目のグループがある場合のみ
    if (groups.length > 1) {
      alerts.push({
        id: `alert_${now - 1}`,
        userId: "user3",
        username: "高橋次郎", 
        groupId: groups[1].id,
        groupName: groups[1].name,
        deadline: groups[1].reportSettings?.deadline || "17:30",
        timestamp: now - 1800000,
        type: 'alert'
      });
    }
    
    return alerts;
    
  } catch (error) {
    console.error('アラート取得エラー:', error);
    return [];
  }
};

// 検索スコア計算関数（AND検索対応版 - HomePage用）
const calculateSearchScoreForHome = (item: TimelineItem, keywords: string[]): number => {
  let totalScore = 0;
  let matchedKeywords = 0;
  
  keywords.forEach(keyword => {
    let score = 0;
    
    // アラートの場合の処理
    if ('type' in item && item.type === 'alert') {
      const alert = item as AlertInfo;
      
      if (alert.username.toLowerCase().includes(keyword)) score += 2;
      if (alert.groupName.toLowerCase().includes(keyword)) score += 3;
      if ('未投稿'.includes(keyword)) score += 3;
      if ('アラート'.includes(keyword)) score += 3;
      
      if (score > 0) matchedKeywords++;
      totalScore += score;
      return;
    }
    
    // 投稿の場合の処理
    const post = item as Post;
    const message = post.message.toLowerCase();
    const username = (post.username || '').toLowerCase();
    const status = (post.status || '未確認').toLowerCase();
    const groupName = (post.groupName || '').toLowerCase();
    
    // 1. タグ完全一致（5点）
    if (post.tags?.some(tag => 
      tag.replace(/^#/, '').toLowerCase() === keyword
    )) {
      score += 5;
    }
    
    // 2. グループ名（現場名）完全一致（4点）
    if (groupName === keyword) {
      score += 4;
    }
    
    // 3. タグ部分一致（3点）
    if (post.tags?.some(tag => 
      tag.replace(/^#/, '').toLowerCase().includes(keyword) &&
      tag.replace(/^#/, '').toLowerCase() !== keyword
    )) {
      score += 3;
    }
    
    // 4. グループ名（現場名）部分一致（3点）
    if (groupName.includes(keyword) && groupName !== keyword) {
      score += 3;
    }
    
    // 5. ユーザー名完全一致（4点）
    if (username === keyword) {
      score += 4;
    }
    
    // 6. ユーザー名部分一致（2点）
    if (username.includes(keyword) && username !== keyword) {
      score += 2;
    }
    
    // 7. メッセージ完全一致（4点）
    if (message === keyword) {
      score += 4;
    }
    
    // 8. メッセージ冒頭一致（3点）
    if (message.startsWith(keyword) && message !== keyword) {
      score += 3;
    }
    
    // 9. メッセージ部分一致（1点）
    if (message.includes(keyword) && !message.startsWith(keyword) && message !== keyword) {
      score += 1;
    }
    
    // 10. ステータス一致（1点）
    if (status.includes(keyword)) {
      score += 1;
    }
    
    if (score > 0) {
      matchedKeywords++;
    }
    
    totalScore += score;
  });
  
  if (matchedKeywords === keywords.length) {
    return totalScore;
  } else {
    return 0;
  }
};

// 5. メインのHomePageコンポーネント
const HomePage: React.FC = () => {
  // 権限管理用の状態を追加
  const [userRole, setUserRole] = useState<'admin' | 'user'>('user');

  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [alerts, setAlerts] = useState<AlertInfo[]>([]);
  const [timelineItems, setTimelineItems] = useState<TimelineItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<TimelineItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  // 画像モーダル用の状態を追加
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [galleryImages, setGalleryImages] = useState<string[]>([]);
  const [galleryIndex, setGalleryIndex] = useState(0);
  
  // フィルタリング用の状態
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [groups, setGroups] = useState<Group[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  
  // 読み込んだ日付のリスト
  const [availableDates, setAvailableDates] = useState<string[]>([]);

  // フィルター表示の状態
  const [showFilter, setShowFilter] = useState(false);
  
  // ★ 修正: StrictMode対応改善版 - デバウンス付き ★
  const initializationRef = useRef(false);
  const retryCountRef = useRef(0);
  const MAX_RETRIES = 3;
  
  // 検索アイコンクリック時のフィルター表示切り替え
  const toggleFilter = () => {
    setShowFilter(prev => !prev);
  };
  
  // 画像をモーダルで表示する関数
  const handleImageClick = (imageUrl: string, allImages: string[]) => {
    const imageIndex = allImages.findIndex(url => url === imageUrl);
    setGalleryImages(allImages);
    setGalleryIndex(imageIndex);
    setGalleryOpen(true);
  };

  // 投稿の詳細ページへ移動する関数
  const handleViewPostDetails = (postId: string, groupId: string) => {
    navigate(`/post/${postId}`);
  };
  
  // 連絡するボタンを押した時の処理
  const handleContact = (groupId: string) => {
    navigate(`/group/${groupId}/post?from=home`);
  };

  // ★ 修正版：確実な初期化とリトライ機能付きデータロード ★
  // ✅ 既存のuseEffectを以下に置き換え（894行目付近）
useEffect(() => {
  let isMounted = true;
  let isInitializing = false;
  
  const loadDataFast = async () => {
    if (isInitializing || initializationRef.current) {
      console.log('⏳ 重複実行スキップ');
      return;
    }
    
    isInitializing = true;
    
    try {
      console.log('🚀 HomePage 高速データロード開始');
      const startTime = performance.now();
      
      setLoading(true);
      
      // 認証確認（高速化）
      const token = localStorage.getItem('daily-report-user-token');
      if (!token) {
        setIsAuthenticated(false);
        return;
      }
      
      setIsAuthenticated(true);
      
      // ユーザー情報取得（既存ロジック使用）
      let userId = localStorage.getItem("daily-report-user-id") || "j94Ngq4aM8aShquxHwhRkiWaIbZ2";
      
      try {
        const currentUser = await getCurrentUser();
        if (currentUser?.id) userId = currentUser.id;
      } catch (error) {
        console.warn('getCurrentUser取得エラー:', error);
      }
      
      const user = {
        id: userId,
        email: localStorage.getItem("daily-report-user-email") || "admin@example.com",
        username: localStorage.getItem("daily-report-username") || "ユーザー",
      };
      
      if (isMounted) {
        setCurrentUser(user);
        
        // 環境変数ベースの権限チェックに変更
        const adminStatus = await isAdmin();
        setUserRole(adminStatus ? 'admin' : 'user');
      }
      
      // ✅ 並列データ取得（最重要な最適化）
      const dbUtil = DBUtil.getInstance();
      
      const [_, allPosts, allGroups] = await Promise.all([
        dbUtil.initDB(),
        dbUtil.getAll(STORES.POSTS),
        getUserGroups(userId).catch(() => [])
      ]);
      
      // 既存の処理ロジックをそのまま使用...
      const processedPosts = allPosts.map(post => {
        // 既存のグループ名解決ロジック
        const groupName = allGroups.find(g => g.id === post.groupId)?.name || 'グループ名なし';
        return { ...post, groupName };
      }).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      
      if (isMounted) {
        setPosts(processedPosts);
        setGroups(allGroups);
        setTimelineItems(processedPosts);
        setFilteredItems(processedPosts);
        initializationRef.current = true;
      }
      
      const endTime = performance.now();
      console.log(`✅ 高速データロード完了: ${Math.round(endTime - startTime)}ms`);
      
    } catch (error) {
      console.error('❌ データロードエラー:', error);
    } finally {
      isInitializing = false;
      if (isMounted) setLoading(false);
    }
  };
  
  loadDataFast();
  
  return () => {
    isMounted = false;
  };
}, []); // 空の依存配列で1回のみ実行



  // ★ 認証されていない場合のリダイレクト（別のuseEffect） ★
  useEffect(() => {
    if (!loading && !isAuthenticated) {
      console.log('🔄 ログインページにリダイレクト');
      navigate('/login');
    }
  }, [loading, isAuthenticated, navigate]);

  // 1. ステータスバッジのスタイルを取得（コンテナ用）
  const getContainerStatusStyle = (status: string) => {
    const baseStyle = {
      padding: '0.5rem 1rem',
      borderRadius: '15px',
      fontSize: '0.8rem',
      fontWeight: '600',
      cursor: 'pointer',
      transition: 'opacity 0.2s',
      border: 'none',
      outline: 'none'
    };
    
    switch (status) {
      case '確認済み':
        return { 
          ...baseStyle, 
          backgroundColor: '#1f5b91',
          color: 'white'
        };
      case '未確認':
      default:
        return { 
          ...baseStyle, 
          backgroundColor: '#ff6b6b',
          color: 'white'
        };
    }
  };

  // 2. ステータス更新処理
  const handleStatusUpdate = async (postId: string, newStatus: string) => {
    try {
      const currentUserId = localStorage.getItem("daily-report-user-id") || "admin_user";
      const currentUsername = localStorage.getItem("daily-report-username") || "ユーザー";
      
      const targetPost = posts.find(post => post.id === postId);
      if (!targetPost) return;
      
      const updatedPost = {
        ...targetPost,
        status: newStatus as '未確認' | '確認済み',
        statusUpdatedAt: Date.now(),
        statusUpdatedBy: currentUserId,
        statusUpdatedByName: currentUsername
      };
      
      const dbUtil = DBUtil.getInstance();
      await dbUtil.initDB();
      await dbUtil.save(STORES.POSTS, updatedPost);
      
      const updatedPosts = posts.map(post => 
        post.id === postId ? updatedPost : post
      );
      setPosts(updatedPosts);
      
      const updatedTimelineItems = timelineItems.map(item => 
        'type' in item ? item : (item.id === postId ? updatedPost : item)
      );
      setTimelineItems(updatedTimelineItems);
      
      const updatedFilteredItems = filteredItems.map(item => 
        'type' in item ? item : (item.id === postId ? updatedPost : item)
      );
      setFilteredItems(updatedFilteredItems);
      
      alert(`✅ ステータスを「${newStatus}」に更新しました`);
    } catch (error) {
      console.error('❌ ステータス更新に失敗:', error);
      alert('ステータスの更新に失敗しました');
    }
  };

  // フィルター関数群
  const filterByDate = (date: string | null) => {
    setSelectedDate(date);
    applyFilters(date, selectedGroup);
  };
  
  const filterByGroup = (groupId: string | null) => {
    setSelectedGroup(groupId);
    applyFilters(selectedDate, groupId);
  };
  
  const applyFilters = (date: string | null, groupId: string | null) => {
    let filtered = [...timelineItems];

    if (searchQuery.trim()) {
      const keywords = searchQuery
        .toLowerCase()
        .split(/[\s,]+/)
        .filter(Boolean);

      const tagKeywords = keywords.filter((keyword) => keyword.startsWith('#'));
      const textKeywords = keywords.filter((keyword) => !keyword.startsWith('#'));
      
      const allKeywords = [...textKeywords, ...tagKeywords.map(tag => tag.substring(1))];
      
      const scoredItems = filtered.map(item => ({
        item: item,
        score: calculateSearchScoreForHome(item, allKeywords)
      }));
      
      filtered = scoredItems
        .filter(scored => scored.score > 0)
        .sort((a, b) => b.score - a.score)
        .map(scored => scored.item);
    }
    
    if (startDate || endDate) {
      filtered = filtered.filter(item => {
        let itemDate;
        
        if ('type' in item && item.type === 'alert') {
          itemDate = formatDate(new Date());
        } else {
          const timeStr = (item as Post).time;
          const datePart = timeStr.split('　')[0];
          const dateOnly = datePart.replace(/（.+）/, '').replace(/\s+/g, '');
          itemDate = dateOnly.replace(/\//g, '-');
        }
        
        if (startDate && itemDate < startDate) {
          return false;
        }
        
        if (endDate && itemDate > endDate) {
          return false;
        }
        
        return true;
      });
    }

    if (date) {
      filtered = filtered.filter(item => {
        if ('type' in item && item.type === 'alert') {
          const today = formatDate(new Date());
          return today === date;
        } else {
          return (item as Post).time.includes(date);
        }
      });
    }
    
    if (groupId) {
      filtered = filtered.filter(item => {
        if ('type' in item && item.type === 'alert') {
          return (item as AlertInfo).groupId === groupId;
        } else {
          return (item as Post).groupId === groupId;
        }
      });
    }
    
    setFilteredItems(filtered);
  };

  useEffect(() => {
    applyFilters(selectedDate, selectedGroup);
  }, [searchQuery, startDate, endDate, selectedDate, selectedGroup]); 
  

  const resetFilters = () => {
    setSearchQuery('');
    setStartDate('');
    setEndDate('');
    setSelectedDate(null);
    setSelectedGroup(null);
  };

  const hasFilterConditions = selectedDate || selectedGroup || searchQuery || startDate || endDate;
  const filterBackgroundHeight = hasFilterConditions ? '470px' : '400px';
  const contentPaddingTop = hasFilterConditions ? '470px' : '400px';

  if (!loading && !isAuthenticated) {
    return <div style={{ padding: '2rem', textAlign: 'center' }}>認証確認中...</div>;
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#ffffff',
        padding: '1.5rem',
        boxSizing: 'border-box',
        paddingBottom: '80px',
      }}
    >
      <Header 
        title="NIPPO" 
        showSearchIcon={true} 
        onSearchClick={toggleFilter} 
        isSearchActive={showFilter}
      />
        
      <style>
        {`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
          }
        `}
      </style>

      <div style={{ 
        maxWidth: '480px', 
        margin: '0 auto',
        paddingTop: showFilter ? contentPaddingTop : '70px',
        transition: 'padding-top 0.3s ease',
      }}>
       
        {showFilter && (
          <>
            <div 
              style={{
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                zIndex: 70,
                backgroundColor: 'transparent',
              }}
              onClick={() => setShowFilter(false)}
            />

            <div 
              id="filter-background-layer"
              style={{
                position: 'fixed', 
                top: 0,
                left: 0,
                width: '100%',
                height: filterBackgroundHeight,
                backgroundColor: '#055A68',
                zIndex: 80,
                backdropFilter: 'blur(4px)',
                animation: 'fadeIn 0.3s ease',
                transition: 'height 0.3s ease',
              }}
              onClick={() => setShowFilter(false)}
            />

            <div
              style={{
                position: 'fixed',
                top: '90px',
                left: 0,
                width: '100%',
                zIndex: 90,
                padding: '0 1.5rem',
                boxSizing: 'border-box',
                animation: 'fadeIn 0.3s ease',
              }}
            >
              <div 
                style={{
                  backgroundColor: '#E6EDED',
                  borderRadius: '12px',
                  padding: '1rem',
                  marginBottom: '1.5rem',
                  boxShadow: '0 4px 10px rgba(0, 102, 114, 0.2)',
                  border: '1px solid rgba(0, 102, 114, 0.1)',
                  maxWidth: '480px',
                  margin: '0 auto',
                  position: 'relative',
                }}
                onClick={(e) => e.stopPropagation()}
              >
                
                <div style={{ 
                  margin: '1rem 1rem 1rem 1rem'  
                }}>
                  <div style={{ position: 'relative' }}>
                    <div style={{
                      position: 'absolute',
                      left: '10px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="rgba(0, 102, 114, 0.6)"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <circle cx="11" cy="11" r="8" />
                        <line x1="21" y1="21" x2="16.65" y2="16.65" />
                      </svg>
                    </div>
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="キーワード・#タグで検索"
                      style={{
                        width: '100%',
                        padding: '0.75rem',
                        paddingLeft: '2.5rem',
                        paddingRight: searchQuery ? '2.5rem' : '0.75rem',
                        backgroundColor: 'rgba(0, 102, 114, 0.05)',
                        color: 'rgb(0, 102, 114)',
                        border: '1px solid rgba(0, 102, 114, 0.2)',
                        borderRadius: '25px',
                        fontSize: '1rem',
                        outline: 'none',
                        boxSizing: 'border-box',
                      }}
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        style={{
                          position: 'absolute',
                          right: '10px',
                          top: '50%',
                          transform: 'translateY(-50%)',
                          background: 'none',
                          border: 'none',
                          color: 'rgba(0, 102, 114, 0.6)',
                          cursor: 'pointer',
                          fontSize: '1rem',
                          padding: '0',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          width: '20px',
                          height: '20px',
                          borderRadius: '50%',
                          backgroundColor: 'rgba(0, 102, 114, 0.1)',
                        }}
                      >
                        ✕
                      </button>
                    )}
                  </div>
                </div>

                <div style={{ 
                  display: 'flex', 
                  gap: '1rem', 
                  marginBottom: '1rem',
                  marginLeft: '1rem',       
                  marginRight: '1rem'       
                }}>
                  <div style={{ flex: 1 }}>
                    <label style={{ 
                      display: 'block', 
                      color: '#055A68', 
                      fontSize: '0.85rem', 
                      marginLeft: '1rem',
                      marginBottom: '0.3rem' 
                    }}>
                      開始日
                    </label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '0.5rem',
                        backgroundColor: 'rgba(0, 102, 114, 0.05)',
                        color: 'rgb(0, 102, 114)',
                        border: '1px solid rgba(0, 102, 114, 0.2)',
                        borderRadius: '8px',
                        fontSize: '1rem',
                        outline: 'none',
                        boxSizing: 'border-box',
                      }}
                    />
                  </div>
                  
                  <div style={{ flex: 1 }}>
                    <label style={{ 
                      display: 'block', 
                      color: '#055A68', 
                      fontSize: '0.85rem', 
                      marginBottom: '0.3rem' 
                    }}>
                      終了日
                    </label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '0.5rem',
                        backgroundColor: 'rgba(0, 102, 114, 0.05)',
                        color: 'rgb(0, 102, 114)',
                        border: '1px solid rgba(0, 102, 114, 0.2)',
                        borderRadius: '8px',
                        fontSize: '1rem',
                        outline: 'none',
                        boxSizing: 'border-box',
                      }}
                    />
                  </div>
                </div>
                
                <div style={{ 
                  marginBottom: '1rem',
                  marginLeft: '1rem',       
                  marginRight: '1rem'       
                }}>
                  <label style={{ 
                    display: 'block', 
                    color: 'rgba(0, 102, 114, 0.8)', 
                    fontSize: '0.85rem', 
                    marginBottom: '0.3rem', 
                    marginLeft: '0rem'
                  }}>
                    グループ
                  </label>
                  <select
                    value={selectedGroup || ''}
                    onChange={(e) => filterByGroup(e.target.value || null)}
                    style={{
                      width: '100%',
                      padding: '0.8rem',
                      backgroundColor: 'rgba(0, 102, 114, 0.05)',
                      color: '#055A68',
                      border: '1px solid rgba(0, 102, 114, 0.2)',
                      borderRadius: '8px',
                      fontSize: '0.9rem',
                      appearance: 'none',
                      WebkitAppearance: 'none',
                      MozAppearance: 'none',
                      backgroundImage: `url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='rgb(0, 102, 114)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")`,
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 0.5rem center',
                      backgroundSize: '1em',
                      paddingRight: '2rem',
                    }}
                  >
                    <option value="">すべてのグループ</option>
                    {groups.map(group => (
                      <option key={group.id} value={group.id}>{group.name}</option>
                    ))}
                  </select>
                </div>
                
                {(selectedDate || selectedGroup || searchQuery || startDate || endDate) && (
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '1rem' }}>
                    <button
                      onClick={resetFilters}
                      style={{
                        padding: '0.5rem 1rem',
                        backgroundColor: 'rgb(0, 102, 114)',
                        border: 'none',
                        color: '#F0DB4F',
                        borderRadius: '25px',
                        fontSize: '0.85rem',
                        fontWeight: 'bold',
                        cursor: 'pointer',
                        marginTop: '1rem',
                        marginBottom: '1rem',
                        marginRight: '1rem'
                      }}
                    >
                      フィルタをクリア
                    </button>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
        
        {loading && (
          <div style={{ textAlign: 'center', color: '#055A68', padding: '2rem' }}>
            <div
              style={{
                width: '30px',
                height: '30px',
                border: '3px solid rgba(5, 90, 104, 0.3)',
                borderTop: '3px solid #055A68',
                borderRadius: '50%',
                animation: 'spin 1s linear infinite',
                margin: '0 auto',
                marginBottom: '1rem',
              }}
            ></div>
            <style>
              {`
                @keyframes spin {
                  0% { transform: rotate(0deg); }
                  100% { transform: rotate(360deg); }
                }
              `}
            </style>
            データを読み込み中...
          </div>
        )}

        {!loading && (
          <div>
            <div
              style={{
                marginTop: '2px',
                marginBottom: '0.5rem',
              }}
            >
              <h3 style={{ 
                color: '#055A68', 
                fontSize: selectedDate || selectedGroup || searchQuery || startDate || endDate ? '1.5rem' : '2rem',
                letterSpacing: 'normal',
                margin: 0
              }}>
                {selectedDate || selectedGroup || searchQuery || startDate || endDate ? 'フィルター適用中' : 'New Posts'}
                {(selectedDate || selectedGroup || searchQuery || startDate || endDate) && filteredItems.length > 0 && (
                  <span style={{ fontSize: '0.9rem', color: '#055A68', marginLeft: '0.5rem' }}>
                    ({filteredItems.length}件)
                  </span>
                )}
              </h3>
            </div>
                    
            {filteredItems.length === 0 ? (
              <div
                style={{
                  backgroundColor: '#E6EDED',
                  padding: '2rem',
                  borderRadius: '12px',
                  textAlign: 'center',
                  color: '#055A68',
                  margin: '2rem 0',
                }}
              >
                {timelineItems.length === 0 ? '投稿はまだありません' : '検索条件に一致する投稿はありません'}
              </div>
            ) : (
              groupItemsByDate()
            )}
          </div>
        )}
      </div>
      
      <ImageGalleryModal
        images={galleryImages}
        initialIndex={galleryIndex}
        isOpen={galleryOpen}
        onClose={() => setGalleryOpen(false)}
      />

      <MainFooterNav />
    </div>
  );

  // タイムラインアイテムを日付ごとにグループ化して表示するヘルパー関数
  function groupItemsByDate() {
    // 日付ごとにグループ化
    const groupedByDate: Record<string, TimelineItem[]> = {};
    
    filteredItems.forEach(item => {
      // 日付部分を取得
      let date;
      if ('type' in item && item.type === 'alert') {
        // アラートの場合は今日の日付を使用
        date = formatDate(new Date());
      } else {
        // 投稿の場合は投稿日時から日付を取得
        date = (item as Post).time.split('　')[0];
      }
      
      if (!groupedByDate[date]) {
        groupedByDate[date] = [];
      }
      groupedByDate[date].push(item);
    });
    
    // 日付ごとに表示
    return Object.entries(groupedByDate)
      .sort(([dateA], [dateB]) => {
        // 日付の比較（新しい順）
        const dateObjA = parseDateString(`${dateA}　00:00`);
        const dateObjB = parseDateString(`${dateB}　00:00`);
        return dateObjB.getTime() - dateObjA.getTime();
      })
      .map(([date, itemsForDate]) => (
        <div key={date} style={{ marginBottom: '2rem' }}>
          <h4 style={{ 
            color: '#F0DB4F', 
            fontSize: '1rem', 
            marginBottom: '1rem',
            backgroundColor: '#066878',
            display: 'inline-block',
            padding: '0.4rem 1rem',
            borderRadius: '20px',
          }}>
            {date}
          </h4>
          
          {/* その日のタイムラインアイテムを表示 */}
          {itemsForDate.map(item => (
            'type' in item && item.type === 'alert' ? (
              // アラートカード
              <AlertCard
                key={item.id}
                alert={item as AlertInfo}
                onContact={handleContact}
                navigate={navigate}
              />
            ) : (
              // 投稿カード - 画像クリックハンドラーを追加
              <PostCard
  key={item.id}
  post={item as Post}
  onViewDetails={handleViewPostDetails}
  onImageClick={handleImageClick}
  navigate={navigate}
  onStatusUpdate={handleStatusUpdate}
  getContainerStatusStyle={getContainerStatusStyle}
  userRole={userRole}  // この行を追加
/>
            )
          ))}
        </div>
      ));
  }
};

// ★ 修正: 削除されていたエクスポート関数を復活 ★
// キャッシュ管理関数（他のコンポーネントから使用される）
let postsCache: Post[] | null = null;
let postsCacheTime = 0;
let groupsCache: Group[] | null = null;
let groupsCacheTime = 0;

export const invalidatePostsCache = () => {
  console.log('🗑️ 投稿キャッシュを無効化');
  postsCache = null;
  postsCacheTime = 0;
};

export const invalidateGroupsCache = () => {
  console.log('🗑️ グループキャッシュを無効化');
  groupsCache = null;
  groupsCacheTime = 0;
};

export const forceRefreshPosts = () => {
  invalidatePostsCache();
  // HomePage コンポーネントに更新を通知するためのイベント
  window.dispatchEvent(new CustomEvent('postsUpdated'));
};

export default HomePage;