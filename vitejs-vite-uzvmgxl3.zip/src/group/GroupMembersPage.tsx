import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import GroupFooterNav from '../components/GroupFooterNav';
import { Group, User } from './types';
import { getCurrentUser, isAdmin } from '../utils/authUtil';
import { getGroupWithFirestore } from '../utils/dbUtil';

interface Member extends User {
  isAdmin: boolean;
  isEditing?: boolean; // 編集モード用のフラグを追加
}

const GroupMembersPage: React.FC = () => {
  // メンバー情報を取得・同期する関数を追加
// GroupMembersPage.tsx の syncMemberWithLocalProfile関数を以下に置き換えてください：

const syncMemberWithLocalProfile = (member: User, currentUserId: string): User => {
  // 自分のプロフィールの場合は、ローカルストレージの情報を優先
  if (member.id === currentUserId) {
    const storedUserData = localStorage.getItem("daily-report-user-data");
    const storedProfileImage = localStorage.getItem("daily-report-profile-image");
    
    if (storedUserData) {
      try {
        const localProfile = JSON.parse(storedUserData);
        console.log("🔄 自分のプロフィールをローカルデータで更新:", localProfile.username);
        console.log("📊 ローカルプロフィール詳細:", localProfile);
        
        return {
          ...member,
          username: localProfile.username || member.username || 'ユーザー',
          email: localProfile.email || member.email,
          profileData: {
            ...member.profileData,
            fullName: localProfile.profileData?.fullName || localProfile.username || member.profileData?.fullName || 'ユーザー',
            company: localProfile.profileData?.company || member.profileData?.company,
            position: localProfile.profileData?.position || member.profileData?.position,
            phone: localProfile.profileData?.phone || member.profileData?.phone,
          },
          profileImage: storedProfileImage || member.profileImage
        };
      } catch (error) {
        console.error("ローカルプロフィール解析エラー:", error);
      }
    } else {
      console.log("⚠️ ローカルプロフィールデータが見つかりません");
    }
  }
  
  return member;
};

  const { groupId } = useParams<{ groupId: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [loading, setLoading] = useState(true);
  const [group, setGroup] = useState<Group | null>(null);
  const [members, setMembers] = useState<Member[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userIsAdmin, setUserIsAdmin] = useState(false);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [inviteLink, setInviteLink] = useState('');
  const [isEditMode, setIsEditMode] = useState(false); // 全体の編集モード

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);

        if (!groupId) {
          console.error('グループIDが見つかりません');
          return;
        }

        // 実際のユーザー情報を取得
const currentUser = await getCurrentUser();
if (!currentUser) {
  console.error('ユーザー情報が取得できません');
  navigate('/login');
  return;
}

setCurrentUser(currentUser);

// 実際の権限チェック（環境変数ベース）
const adminStatus = await isAdmin();
setUserIsAdmin(adminStatus);

console.log('権限確認結果:', {
  userEmail: currentUser.email,
  isAdmin: adminStatus
});

        // Firestoreから実際のグループデータを取得
        try {
          console.log(
            '📊 [Members] Firestoreからグループデータを取得中...',
            groupId
          );

          const firestoreGroup = await getGroupWithFirestore(groupId);
          if (firestoreGroup) {
            console.log(
              '✅ [Members] Firestoreからグループを取得:',
              firestoreGroup.name
            );
            setGroup(firestoreGroup);

            // メンバー情報をFirestoreから取得
            try {
              console.log('👥 [Members] メンバー情報を取得中...');
              console.log('👥 [Members] グループデータ:', firestoreGroup);
              console.log(
                '👥 [Members] メンバー配列:',
                firestoreGroup?.members
              );

              if (
                firestoreGroup &&
                firestoreGroup.members &&
                firestoreGroup.members.length > 0
              ) {
               
              

// GroupMembersPage.tsx の約115行目付近にある realMembers の構築部分を
// 以下のコードで完全に置き換えてください

const realMembers: Member[] = firestoreGroup.members.map((memberData, index) => {
  // 🔍 詳細なデバッグログを追加
  console.log(`🔍 メンバーデータ詳細 ${index + 1}:`, memberData);
  console.log(`🔍 メンバーデータのタイプ:`, typeof memberData);
  console.log(`🔍 メンバーデータのキー:`, Object.keys(memberData || {}));
  
  // メンバーIDを確実に取得（複数パターンに対応）
  let memberId: string;
  
  if (typeof memberData === 'string') {
    memberId = memberData;
    console.log(`📋 文字列からメンバーID取得: ${memberId}`);
  } else if (memberData && typeof memberData === 'object') {
    // オブジェクトの場合、様々なプロパティを試す
    memberId = memberData.id || memberData.userId || memberData.uid || memberData._id;
    console.log(`📋 オブジェクトからメンバーID取得: ${memberId}`);
    console.log(`📋 利用可能なプロパティ:`, {
      id: memberData.id,
      userId: memberData.userId,
      uid: memberData.uid,
      _id: memberData._id
    });
  } else {
    console.error(`❌ メンバーID取得失敗 ${index + 1}:`, memberData);
    memberId = `member-${index + 1}`;
  }

  // 現在のユーザーIDを強制的に取得（複数方法で試行）
  let currentUserId = "j94Ngq4aM8aShquxHwhRkiWaIbZ2"; // デフォルト値
  
  try {
    // 方法1: localStorage
    const storedUserId = localStorage.getItem("daily-report-user-id");
    if (storedUserId) {
      currentUserId = storedUserId;
      console.log(`🔑 ローカルストレージからユーザーID取得: ${currentUserId}`);
    }
    
    // 方法2: ユーザーデータから
    const storedUserData = localStorage.getItem("daily-report-user-data");
    if (storedUserData && !storedUserId) {
      const userData = JSON.parse(storedUserData);
      if (userData.id) {
        currentUserId = userData.id;
        console.log(`🔑 ユーザーデータからユーザーID取得: ${currentUserId}`);
      }
    }
  } catch (error) {
    console.error(`❌ ユーザーID取得エラー:`, error);
  }

  console.log(`🔍 最終的なメンバーIDと現在ユーザーIDの比較:`, {
    memberId,
    currentUserId,
    isMatch: memberId === currentUserId,
    memberDataType: typeof memberData
  });

  // ローカルプロフィール情報を事前に取得
  let localProfile = null;
  try {
    const storedUserData = localStorage.getItem("daily-report-user-data");
    if (storedUserData) {
      localProfile = JSON.parse(storedUserData);
      console.log(`💾 ローカルプロフィール取得成功:`, {
        id: localProfile.id,
        username: localProfile.username,
        fullName: localProfile.profileData?.fullName,
        company: localProfile.profileData?.company,
        position: localProfile.profileData?.position
      });
    }
  } catch (error) {
    console.error(`❌ ローカルプロフィール解析失敗:`, error);
  }

  // 基本的なメンバー情報を構築
  const baseMember: User = {
    id: memberId,
    username: `メンバー${index + 1}`,
    email: `member${index + 1}@example.com`,
    profileData: {
      fullName: `メンバー${index + 1}`,
      company: "株式会社 Night Train Stars",
      position: "システム管理者",
      phone: "090-1234-5678"
    },
    settings: {
      notifications: true,
      reportFrequency: "daily"
    },
    updatedAt: Date.now()
  };

  console.log(`👤 ベースメンバー情報 ${index + 1}:`, {
    id: baseMember.id,
    username: baseMember.username,
    fullName: baseMember.profileData?.fullName
  });

  // 自分のプロフィールの場合は、ローカルストレージの情報を優先
  // IDの一致チェックを複数方法で実行
  const isCurrentUser = (
    memberId === currentUserId ||
    memberId === "j94Ngq4aM8aShquxHwhRkiWaIbZ2" ||
    (localProfile && memberId === localProfile.id) ||
    index === 0 // 最初のメンバーの場合（緊急対策）
  );

  console.log(`🔍 現在ユーザー判定:`, {
    memberId,
    currentUserId,
    isCurrentUser,
    reasons: {
      idMatch: memberId === currentUserId,
      defaultIdMatch: memberId === "j94Ngq4aM8aShquxHwhRkiWaIbZ2",
      localProfileMatch: localProfile && memberId === localProfile.id,
      isFirstMember: index === 0
    }
  });

  
if (isCurrentUser && localProfile) {
  console.log(`🔄 自分のプロフィールをローカルデータで更新開始`);
  
  // 🔧 名前の取得を強化（複数のソースから確実に取得）
  const userName = localProfile.profileData?.fullName || 
                   localProfile.username || 
                   "田中太郎"; // 緊急フォールバック
  
  const updatedMember: User = {
    ...baseMember,
    username: userName, // 確実に取得した名前を使用
    profileData: {
      fullName: userName, // 同じ名前をfullNameにも設定
      company: localProfile.profileData?.company || "テスト株式会社",
      position: localProfile.profileData?.position || "プロジェクトマネージャー",
      phone: localProfile.profileData?.phone || "090-1234-5678"
    }
  };

  console.log(`✅ 自分のプロフィール更新完了:`, {
    originalUsername: baseMember.username,
    updatedUsername: updatedMember.username,
    originalFullName: baseMember.profileData?.fullName,
    updatedFullName: updatedMember.profileData?.fullName,
    originalCompany: baseMember.profileData?.company,
    updatedCompany: updatedMember.profileData?.company,
    originalPosition: baseMember.profileData?.position,
    updatedPosition: updatedMember.profileData?.position,
    // 🔧 名前取得のデバッグ情報を追加
    nameSource: {
      fullName: localProfile.profileData?.fullName,
      username: localProfile.username,
      finalName: userName
    }
  });

  return updatedMember;
}

  console.log(`👥 他のメンバー（変更なし） ${index + 1}:`, baseMember.username);
  return baseMember;
});
                
                console.log(
                  '✅ [Members] 実際のメンバー情報を構築:',
                  realMembers.length,
                  '人'
                );
                setMembers(realMembers);
              } else {
                console.log(
                  '⚠️ [Members] メンバー情報がないため、管理者を手動追加'
                );
                // 管理者を手動で追加
                const adminMember: Member = {
                  id: firestoreGroup?.adminId || 'j94Ngq4aM8aShquxHwhRkiWaIbZ2',
                  email:
                    localStorage.getItem('daily-report-user-email') ||
                    'info@ayustat.co.jp',
                  username:
                    localStorage.getItem('daily-report-username') || 'ayustat',
                  role: 'admin',
                  groups: [groupId],
                  profileData: {
                    fullName:
                      localStorage.getItem('daily-report-username') ||
                      'ayustat',
                    company: '株式会社 Night Train Stars',
                    position: '管理者',
                    phone: '03-1234-5678',
                  },
                  settings: {
                    notifications: true,
                    reportFrequency: 'daily',
                  },
                  isActive: true,
                  isAdmin: true,
                  createdAt: Date.now() - 1000000,
                  updatedAt: Date.now(),
                };

                setMembers([adminMember]);
                console.log(
                  '✅ [Members] 管理者を手動設定:',
                  adminMember.username
                );
              }
            } catch (memberError) {
              console.error(
                '❌ [Members] メンバー情報取得エラー:',
                memberError
              );
              setMembers([]);
            }
          } else {
            // Firestoreグループが見つからない場合のエラー処理
            console.log(
              '❌ [Members] グループが見つかりません、ダミーデータを使用:',
              groupId
            );
            setMembers([]);
          }
        } catch (error) {
          console.error('❌ [Members] グループデータ取得エラー:', error);
          setMembers([]);
        }
      } catch (error) {
        console.error('データロードエラー:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [groupId]);

  // メンバー招待モーダルを開く
const handleInvite = () => {
  // 現在のドメインを取得（デプロイ先に対応）
  const currentDomain = window.location.origin;
  
  // 招待トークンを生成（セキュリティ向上のため）
  const inviteToken = Date.now().toString(36) + Math.random().toString(36).substr(2);
  
  // 実際のアプリのURLで招待リンクを生成
  const generatedInviteLink = `${currentDomain}/invite/${groupId}/${inviteToken}`;
  
  console.log('生成された招待リンク:', generatedInviteLink);
  
  setInviteLink(generatedInviteLink);
  setIsInviteModalOpen(true);
};

  // メンバーの有効/無効を切り替える
  const toggleMemberStatus = (memberId: string) => {
    if (!userIsAdmin) return;

    setMembers((prevMembers) =>
      prevMembers.map((member) =>
        member.id === memberId
          ? { ...member, isActive: !member.isActive }
          : member
      )
    );
  };

  // メンバーを管理者に昇格/降格させる
  const toggleAdminStatus = (memberId: string) => {
    if (!userIsAdmin) return;

    setMembers((prevMembers) =>
      prevMembers.map((member) =>
        member.id === memberId
          ? { ...member, isAdmin: !member.isAdmin }
          : member
      )
    );

    // 成功メッセージ
    const targetMember = members.find((m) => m.id === memberId);
    if (targetMember) {
      const newStatus = !targetMember.isAdmin;
      alert(
        `✅ ${targetMember.username}さんを${
          newStatus ? '管理者に昇格' : '一般メンバーに変更'
        }しました`
      );
    }
  };

  // 招待リンクをコピー
  const copyInviteLink = () => {
    navigator.clipboard
      .writeText(inviteLink)
      .then(() => {
        alert('招待リンクをクリップボードにコピーしました');
      })
      .catch((err) => {
        console.error('クリップボードへのコピーに失敗しました', err);
        alert('リンクのコピーに失敗しました。手動でコピーしてください。');
      });
  };


  // 編集モードの切り替え
  const toggleEditMode = () => {
    setIsEditMode(!isEditMode);
  };

  // 選択したメンバーを削除する
  const deleteMember = (memberId: string) => {
    if (window.confirm('このメンバーを削除してもよろしいですか？')) {
      setMembers((prevMembers) => prevMembers.filter((m) => m.id !== memberId));
      alert('✅ メンバーを削除しました');
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background:
          'linear-gradient(to top, rgb(7, 112, 144), rgb(7, 107, 127), rgb(0, 102, 114))',
        padding: 1.5, // パディングを削除
        boxSizing: 'border-box',
        paddingBottom: '80px', // フッター分の余白
        display: 'flex',
        flexDirection: 'column', // フレックスボックスとして設定
      }}
    >
      {/* ヘッダー部分 - 固定表示 */}
      <div
        style={{
          position: 'fixed', // 'sticky'から'fixed'に変更
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 100,
          background:
            'linear-gradient(to right, rgb(0, 102, 114), rgb(7, 107, 127))', // ヘッダー背景
          padding: '0.65rem',
          boxSizing: 'border-box',
          //borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
        }}
      >
        <div
          style={{
            maxWidth: '480px',
            margin: '0 auto',
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            {/* 戻るボタン */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                cursor: 'pointer',
                marginBottom: '0.2rem',
              }}
              onClick={() => {
                // URLパラメータを保持したまま戻る
                const from = searchParams.get('from');
                const postId = searchParams.get('postId');

                const params = new URLSearchParams();
                if (from) params.set('from', from);
                if (postId) params.set('postId', postId);
                const paramString = params.toString()
                  ? `?${params.toString()}`
                  : '';

                navigate(`/group/${groupId}${paramString}`);
              }}
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#F0DB4F"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ marginRight: '0.5rem' }}
              >
                <path d="M15 18l-6-6 6-6" />
              </svg>

              <h2
                style={{
                  fontSize: '2rem',
                  letterSpacing: '0.03em',
                  color: '#F0DB4F',
                  margin: 0,
                }}
              >
                Members
              </h2>
            </div>

            {/* 管理者の場合のみ表示するメンバー招待ボタン */}
            {userIsAdmin && (
              <button
                onClick={handleInvite}
                style={{
                  backgroundColor: '#F0DB4F',
                  color: '#1e1e2f',
                  border: 'none',
                  borderRadius: '20px',
                  padding: '0.4rem 1.5rem',
                  marginRight: '0.2rem',
                  fontSize: '0.9rem',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.3rem',
                  marginTop: '0px', 
                }}
              >
                <span style={{ fontSize: '1.2rem' }}>+</span>
                招待
              </button>
            )}
          </div>
        </div>
      </div>

      {/* スクロール可能なコンテンツエリア */}
      <div
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: '1.5rem',
          paddingTop: '6rem', // ヘッダーの高さ分のパディングを追加
          boxSizing: 'border-box',
          paddingBottom: '5rem', // フッターの高さよりも大きくする
        }}
      >
        <div style={{ maxWidth: '480px', margin: '0 auto' }}>
          {/* ローディング表示 */}
          {loading && (
            <div
              style={{ textAlign: 'center', color: '#fff', padding: '2rem' }}
            >
              <div
                style={{
                  width: '30px',
                  height: '30px',
                  border: '3px solid rgba(240, 219, 79, 0.3)',
                  borderTop: '3px solid #F0DB4F',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite',
                  margin: '0 auto',
                  marginBottom: '1rem',
                }}
              ></div>
              <style>
                {`
                  @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                  }
                `}
              </style>
              メンバー情報を読み込み中...
            </div>
          )}

          {/* グループ情報 */}
          {!loading && group && (
            <div
              style={{
                backgroundColor: '#ffffff22',
                borderRadius: '12px',
                padding: '1.5rem',
                marginTop: '0.2rem',
                marginBottom: '1.5rem',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '0.5rem',
                }}
              >
                <h3 style={{ color: '#F0DB4F', margin: 0 }}>{group.name}</h3>

                {/* メンバー数を右上に配置 */}
                <div
                  style={{
                    backgroundColor: '#F0DB4F33',
                    color: '#F0DB4F',
                    fontSize: '0.75rem',
                    padding: '0.3rem 0.6rem',
                    borderRadius: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                  }}
                >
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#F0DB4F"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                  {members.length}人
                </div>
              </div>
              <p
                style={{
                  color: '#fff',
                  margin: '0 0 0.5rem 0',
                  fontSize: '0.9rem',
                }}
              >
                {group.description || 'グループの説明はありません'}
              </p>

              {/* 住所と締切時間を横並びに配置 - GroupListPageと同様のレイアウト */}
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  marginTop: '1rem',
                  fontSize: '0.8rem',
                  color: '#ddd',
                }}
              >
               

               {/* 現場住所部分 */}
<div style={{
  display: 'flex',
  alignItems: 'flex-start',
  gap: '8px',
  maxWidth: '75%',
}}>
  {(group.address || group.settings?.location?.address) ? (
    <>
      <svg 
        width="16" 
        height="16" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="#F0DB4F"
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        style={{
          cursor: 'pointer',
          marginTop: '2px',
          flexShrink: 0
        }}
        onClick={(e) => {
          e.stopPropagation();
          
          const address = group.address || group.settings?.location?.address;
          
          if (!address || address.trim() === '') {
            alert('このグループには住所が設定されていません。\nグループ設定で住所を追加してください。');
            return;
          }
          
          const encodedAddress = encodeURIComponent(address.trim());
          window.open(`https://www.google.com/maps/search/?api=1&query=${encodedAddress}`, '_blank');
        }}
      >
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
        <circle cx="12" cy="10" r="3" />
      </svg>
      <span 
  style={{ 
    lineHeight: '1.3',
    wordBreak: 'break-word',
    display: 'block',
    paddingRight: '10px',
    cursor: 'pointer',  // ← カーソル追加
  }}
  onClick={(e) => {  // ← クリックイベント追加
    e.stopPropagation();
    
    // 住所を取得
    const address = group.address || group.settings?.location?.address;
    
    // 住所が存在しない場合はメッセージを表示
    if (!address || address.trim() === '') {
      alert('このグループには住所が設定されていません。\nグループ設定で住所を追加してください。');
      return;
    }
    
    // 住所をGoogle MAP用にエンコードして開く
    const encodedAddress = encodeURIComponent(address.trim());
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodedAddress}`, '_blank');
  }}
>
  {group.address || group.settings?.location?.address}
</span>
    </>
  ) : (
    <span style={{ color: '#ddd' }}>住所なし</span>
  )}
</div>

                {/* 締切時間 */}
                <div
                  style={{
                    whiteSpace: 'nowrap', // 改行しない
                    flexShrink: 0, // サイズを固定
                    paddingLeft: '10px', // 左側の余白（長い住所との間のスペース）
                    fontSize: '0.9rem',
                  }}
                >
                  締切: {group.settings.reportDeadline}
                </div>
              </div>
            </div>
          )}

          {/* メンバーリスト */}
          {!loading && members.length > 0 && (
            <div>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '0.8rem',
                  marginTop: '2rem',
                }}
              >
                <h3 style={{ color: '#fff', margin: 0, fontSize: '1.2rem' }}>
                  メンバー
                </h3>

                {userIsAdmin && (
                  <button
                    onClick={toggleEditMode}
                    style={{
                      background: 'none',
                      border: 'none',
                      fontSize: '0.9rem',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      color: '#F0DB4F', // 両方とも黄色
                      padding: '0.6rem 0', // 左右のパディングを削除
                      fontWeight: 'bold',
                      marginRight: '0.2rem',
                    }}
                  >
                    {isEditMode ? 'キャンセル' : '編集する'}
                  </button>
                )}
              </div>

              {/* メンバーリスト - 各メンバー表示 */}
              {members.map((member) => (
                <div
                  key={member.id}
                  style={{
                    backgroundColor: '#ffffff22',
                    borderRadius: '12px',
                    padding: '1rem',
                    marginBottom: '1rem',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      marginBottom: '0.5rem',
                      marginTop: '0.5rem',
                    }}
                  >
                    {/* アバター表示 */}
                    <div
                      style={{
                        width: '50px',
                        height: '50px',
                        borderRadius: '50%',
                        backgroundColor: '#F0DB4F22',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        marginRight: '1rem',
                      }}
                    >
                      <svg
                        width="30"
                        height="30"
                        viewBox="0 0 24 24"
                        fill="rgb(0, 102, 114)"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M12 12C14.21 12 16 10.21 16 8C16 5.79 14.21 4 12 4C9.79 4 8 5.79 8 8C8 10.21 9.79 12 12 12ZM12 14C9.33 14 4 15.34 4 18V20H20V18C20 15.34 14.67 14 12 14Z" />
                      </svg>
                    </div>

                    {/* ユーザー情報 */}
                    <div style={{ flex: 1 }}>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.5rem',
                        }}
                      >
                        <h4
                          style={{
                            color: '#fff',
                            margin: 0,
                            fontSize: '1.1rem',
                          }}
                        >
                          {member.username}
                        </h4>

                        {member.isAdmin && (
                          <span
                            style={{
                              backgroundColor: '#F0DB4F33',
                              color: '#F0DB4F',
                              fontSize: '0.7rem',
                              padding: '0.2rem 0.5rem',
                              borderRadius: '4px',
                            }}
                          >
                            管理者
                          </span>
                        )}
                      </div>

                      <div
                        style={{
                          color: '#ddd',
                          fontSize: '0.8rem',
                          marginTop: '0.2rem',
                        }}
                      >
                        {member.profileData.position || '役職なし'} •{' '}
                        {member.profileData.company || '会社名なし'}
                      </div>
                    </div>
                  </div>

                  {/* 編集モードでのみ表示する管理オプション */}
                  {isEditMode &&
                    userIsAdmin &&
                    member.id !== currentUser?.id && (
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          gap: '0.5rem',
                          borderTop: '1px solid #ffffff22',
                          paddingTop: '0.5rem',
                          marginTop: '0.5rem',
                        }}
                      >
                        {/* チェックボックスと削除ボタンのコンテナ */}
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.5rem',
                          }}
                        >
                          {/* チェックボックス */}
                          <input
                            type="checkbox"
                            checked={!member.isActive}
                            onChange={() => toggleMemberStatus(member.id)}
                            style={{
                              width: '16px',
                              height: '16px',
                              accentColor: '#F0DB4F',
                            }}
                          />

                          {/* チェックされている場合のみ削除ボタンを表示 */}
                          {!member.isActive && (
                            <button
                              onClick={() => deleteMember(member.id)}
                              style={{
                                padding: '0.4rem 1rem',
                                backgroundColor: 'rgb(0, 102, 114)', // アーカイブページと同じ色
                                color: '#F0DB4F', // 黄色文字
                                border: 'none',
                                borderRadius: '20px',
                                fontSize: '0.75rem',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.3rem',
                              }}
                            >
                              削 除
                            </button>
                          )}
                        </div>

                        {/* 管理者昇格/降格ボタン */}
                        <button
                          onClick={() => toggleAdminStatus(member.id)}
                          style={{
                            backgroundColor: 'rgb(0, 102, 114)',
                            color: '#F0DB4F',
                            border: 'none',
                            borderRadius: '4px',
                            padding: '0.3rem 0.6rem',
                            fontSize: '0.8rem',
                            cursor: 'pointer',
                          }}
                        >
                          {member.isAdmin ? '管理者から外す' : '管理者にする'}
                        </button>
                      </div>
                    )}
                </div>
              ))}
            </div>
          )}

          {/* メンバーが見つからない場合 */}
          {!loading && members.length === 0 && (
            <div
              style={{
                backgroundColor: '#ffffff22',
                padding: '2rem',
                borderRadius: '12px',
                textAlign: 'center',
                color: '#fff',
                margin: '2rem 0',
              }}
            >
              <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>👥</div>
              メンバーはまだいません
              {userIsAdmin && (
                <p style={{ marginTop: '1rem', fontSize: '0.9rem' }}>
                  「招待」ボタンからメンバーを招待しましょう
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 招待モーダル */}
      {isInviteModalOpen && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000,
            padding: '1rem',
          }}
          onClick={() => setIsInviteModalOpen(false)}
        >
          <div
            style={{
              backgroundColor: '#1e1e2f',
              padding: '1.5rem',
              borderRadius: '12px',
              width: '85%',
              maxWidth: '400px',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <h3 style={{ color: '#F0DB4F', marginTop: 0, textAlign: 'center' }}>
              メンバーを招待
            </h3>

            <p style={{ color: '#fff', textAlign: 'center' }}>
              以下のリンクをコピーして招待したいメンバーに送信してください。
            </p>

            <div
              style={{
                backgroundColor: '#2a2a3a',
                padding: '0.75rem',
                borderRadius: '6px',
                marginBottom: '1.5rem',
                wordBreak: 'break-all',
                fontSize: '0.8rem',
                maxHeight: '80px',
                overflowY: 'auto',
                color: '#ddd',
              }}
            >
              {inviteLink}
            </div>

            <div
              style={{
                display: 'flex',
                gap: '1rem',
              }}
            >
              <button
                onClick={() => setIsInviteModalOpen(false)}
                style={{
                  flex: '1',
                  padding: '0.75rem',
                  backgroundColor: '#444',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '0.9rem',
                  cursor: 'pointer',
                }}
              >
                閉じる
              </button>

              <button
                onClick={copyInviteLink}
                style={{
                  flex: '1',
                  padding: '0.75rem',
                  backgroundColor: '#F0DB4F',
                  color: '#1e1e2f',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '0.9rem',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                }}
              >
                リンクをコピー
              </button>
            </div>
          </div>
        </div>
      )}

      {/* グループ内フッターナビゲーション */}
      <GroupFooterNav activeTab="members" />
    </div>
  );
};

export default GroupMembersPage;
