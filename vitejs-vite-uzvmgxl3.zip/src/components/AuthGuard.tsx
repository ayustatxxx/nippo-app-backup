// src/components/AuthGuard.tsx
import React, { useState, useEffect, ReactNode } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { getCurrentUser } from '../firebase/auth';

interface AuthGuardProps {
  children: ReactNode;
}

const AuthGuard: React.FC<AuthGuardProps> = ({ children }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const checkAuth = () => {
      const user = getCurrentUser();
      if (user) {
        setIsAuthenticated(true);
        console.log('認証済み:', user.email);
      } else {
        setIsAuthenticated(false);
        console.log('未認証 - ログインページへ');
        
        // 現在のURLを保存
        const currentPath = location.pathname + location.search;
        sessionStorage.setItem('redirectAfterLogin', currentPath);
        
        navigate('/login', { replace: true });
      }
      setIsLoading(false);
    };

    const timer = setTimeout(checkAuth, 100);
    
    return () => clearTimeout(timer);
  }, [navigate, location]);

  if (isLoading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "linear-gradient(to top, rgb(7, 112, 144), rgb(7, 107, 127), rgb(0, 102, 114))",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div style={{ color: "#fff", textAlign: "center" }}>
          <div
            style={{
              width: "40px",
              height: "40px",
              border: "4px solid rgba(240, 219, 79, 0.3)",
              borderTop: "4px solid #F0DB4F",
              borderRadius: "50%",
              animation: "spin 1s linear infinite",
              margin: "0 auto 1rem",
            }}
          />
          <p>認証確認中...</p>
        </div>
      </div>
    );
  }

  return isAuthenticated ? <>{children}</> : null;
};

export default AuthGuard;