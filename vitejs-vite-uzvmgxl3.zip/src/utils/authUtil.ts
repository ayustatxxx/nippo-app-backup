// utils/authUtil.ts - 最小限修正版（安全）
import { User } from "../types";
import { DBUtil, STORES } from "./dbUtil";
// 既存のインポート文の後に追加
import { 
  syncCurrentUser, 
  createUserProfile, 
  getUser as getFirestoreUser 
} from '../firebase/firestore';
import { getCurrentUser as getFirebaseUser } from '../firebase/auth';

// 現在のログインユーザー情報を取得
// Firebase + Firestore対応版のgetCurrentUser関数
export const getCurrentUser = async (): Promise<User | null> => {
  try {
    console.log('🔍 現在のユーザーを確認中...');
    
    // 1. Firebase認証ユーザーを確認
    const firebaseUser = getFirebaseUser();
    
    if (firebaseUser) {
      console.log('✅ Firebase認証ユーザーを発見:', firebaseUser.email);
      
      // 2. Firestoreと同期
      const syncedUser = await syncCurrentUser(firebaseUser);
      console.log('🔍 syncedUser結果:', syncedUser); // デバッグログ追加
      
      if (syncedUser) {
        console.log('✅ Firestoreと同期完了:', syncedUser.username);
        return syncedUser;
      } else {
        console.log('⚠️ syncCurrentUserがundefinedを返しました');
        
        // 3. Firestoreから直接取得を試行
        try {
          const directUser = await getFirestoreUser(firebaseUser.uid);
          if (directUser) {
            console.log('✅ Firestoreから直接ユーザー取得成功');
            return directUser;
          }
        } catch (error) {
          console.error('❌ Firestore直接取得エラー:', error);
        }
      }
    }
    
    // 4. ローカルストレージからのフォールバック
    const localUserId = localStorage.getItem("daily-report-user-id");
    if (localUserId) {
      console.log('📱 ローカルストレージからユーザーIDを取得:', localUserId);
      
      const storedUserData = localStorage.getItem("daily-report-user-data");
      if (storedUserData) {
        try {
          const userData = JSON.parse(storedUserData);
          console.log('✅ ローカルストレージからユーザーデータを復元');
          return userData;
        } catch (error) {
          console.error('❌ ローカルストレージのデータ解析エラー:', error);
        }
      }
    }

    console.log('⚠️ ユーザー情報が見つかりません');
    return null;
    
  } catch (error) {
    console.error('❌ ユーザー取得エラー:', error);
    return null;
  }
};

// ユーザーのロールを確認（管理者かどうか）
export const isAdmin = async (): Promise<boolean> => {
  try {
    // 一時的に直接メールアドレスを指定
    const adminEmail = 'info@ayustat.co.jp';
    const userEmail = localStorage.getItem("daily-report-user-email");
    
    console.log('権限チェック:', { adminEmail, userEmail });
    
    return userEmail === adminEmail;
  } catch (error) {
    console.error('管理者権限チェックエラー:', error);
    return false;
  }
};

// 【修正箇所】ダミーユーザーデータをセットアップ（実証実験用に無効化）
export const setupDummyUsers = async (): Promise<void> => {
  console.log('🚫 実証実験モード：ダミーユーザー機能は無効化されています');
  console.log('💡 実際のユーザー登録・ログインをご利用ください');
  
  // 既存のダミーデータ作成処理は全てコメントアウト
  /*
  const dbUtil = DBUtil.getInstance();
  await dbUtil.initDB();
  
  // 既存のユーザーを確認
  const users = await dbUtil.getAll<User>(STORES.USERS);
  if (users.length > 0) return; // すでにユーザーがいれば何もしない
  
  // 以下のダミーデータ作成は実証実験では使用しない
  */
  
  return;
};

// 新しい関数を追加
export const getUserRole = async (): Promise<'admin' | 'user'> => {
  const adminStatus = await isAdmin();
  return adminStatus ? 'admin' : 'user';
};