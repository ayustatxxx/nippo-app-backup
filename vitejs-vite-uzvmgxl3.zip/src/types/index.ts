// types/index.ts

// グループの型定義
// グループの型定義（統一版）
export interface Group {
  id: string;              
  name: string;            
  description: string;     
  address?: string;        
  
  // 管理者情報（両方の形式に対応）
  adminId?: string;        
  adminIds?: string[];     
  
  // メンバー情報（両方の形式に対応）
  members?: string[];      
  memberIds?: string[];    
  
  // 削除機能
  isDeleted?: boolean;     
  deletedAt?: number;      
  deletedBy?: string;      
  permanentlyDeleted?: boolean; 
  permanentDeletedAt?: number;  
  
  // 招待機能
  inviteCode?: string;
  
  settings: {              
    reportDeadline: string; 
    reportFrequency?: 'daily' | 'weekly' | 'monthly' | 'custom';
    reportSettings?: {       
      frequency?: 'daily' | 'weekly' | 'monthly' | 'custom';
      customDays?: number;  
    };
    allowMemberInvite?: boolean;
    autoArchive?: boolean;
    location?: {
      address?: string;
      coordinates?: { lat: number; lng: number; };
    };
  };
  
  createdAt: number;        
  updatedAt: number;        
}

// ユーザーの型定義
export interface User {
  id: string;           
  email: string;        
  username: string;     
  role: 'admin' | 'user'; 
  groups: string[];     
  profileData: {        
    fullName?: string;  
    company?: string;   
    position?: string;  
    phone?: string;     
  };
  settings: {           
    notifications: boolean; 
    reportFrequency: 'daily' | 'weekly' | 'monthly'; 
  };
  isActive: boolean;    
  createdAt: number;    
  updatedAt: number;    
}

// 投稿の型定義（ステータス機能を追加）
export interface Post {
  id: string;              
  userId: string;          
  username?: string;       
  groupId: string;         
  groupName?: string;      
  message: string;         
  photoUrls: string[];     
  tags?: string[];         
  time: string;            
  timestamp: number;       
  isWorkTimePost?: boolean; 
  checkOutTime?: number;   
  isEdited?: boolean;      
  updatedAt?: number;      
  memos?: Memo[];
  
  // 新規追加: ステータス管理
  status: '未確認' | '確認済み';
  statusUpdatedAt?: number;   // ステータス更新日時
  statusUpdatedBy?: string;   // ステータス更新者ID
  statusUpdatedByName?: string; // ステータス更新者名
}

// メモの型定義（ステータス削除、シンプル化）
export interface Memo {
  id: string;              
  content: string;         // メモの内容のみ
  createdAt: number;       
  createdBy: string;       
  createdByName: string;   
  postId: string;          
  imageUrls?: string[];    // 画像URL（オプション）
  tags?: string[];         // タグ（オプション）
}